/*
 * Heart Rate Monitor - main application
 * NCS v3.2.4 / nRF52-DK + MAX30102
 */

#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/logging/log.h>

#include "../drivers/max30102/max30102.h"
#include "ble_hrs.h"

LOG_MODULE_REGISTER(main, LOG_LEVEL_INF);

#define SAMPLE_RATE_HZ     100U
#define SAMPLE_INTERVAL_MS (1000U / SAMPLE_RATE_HZ)

#define I2C_NODE DT_NODELABEL(i2c0)

int main(void)
{
	LOG_INF("Heart Rate Monitor starting");

	/* --- BLE --- */
	int ret = bt_hrs_init();
	if (ret) {
		LOG_ERR("BLE init failed: %d", ret);
		return ret;
	}

	/* --- I2C device --- */
	const struct device *i2c_dev = DEVICE_DT_GET(I2C_NODE);

	if (!device_is_ready(i2c_dev)) {
		LOG_ERR("I2C device not ready");
		return -ENODEV;
	}

	/* --- Sensor init --- */
	ret = max30102_init(i2c_dev);
	if (ret) {
		LOG_ERR("MAX30102 init failed: %d", ret);
		return ret;
	}

	/* --- Sampling loop --- */
	uint32_t ir_buf[MAX30102_SAMPLES_PER_CALC];
	size_t n = 0;

	LOG_INF("Sampling at %u Hz, window = %u samples",
		SAMPLE_RATE_HZ, MAX30102_SAMPLES_PER_CALC);

	while (1) {
		struct max30102_raw_sample s;
		int got = max30102_read_sample(i2c_dev, &s);

		if (got == 1) {
			ir_buf[n++] = s.ir;

			if (n >= MAX30102_SAMPLES_PER_CALC) {
				uint8_t bpm = max30102_compute_hr(
					ir_buf,
					MAX30102_SAMPLES_PER_CALC,
					SAMPLE_RATE_HZ);

				if (bpm > 0) {
					LOG_INF("HR: %u bpm", bpm);
					ret = bt_hrs_notify(bpm);
					if (ret && ret != -ENOTCONN) {
						LOG_WRN("Notify failed: %d", ret);
					}
				} else {
					LOG_WRN("HR invalid - check sensor contact");
				}
				n = 0;
			}
		} else if (got < 0) {
			LOG_ERR("Sensor read error: %d", got);
		}

		k_msleep(SAMPLE_INTERVAL_MS);
	}

	return 0;
}
