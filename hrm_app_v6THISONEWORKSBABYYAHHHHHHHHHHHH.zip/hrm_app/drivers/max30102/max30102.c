/*
 * MAX30102 driver - NCS v3.2.4
 * SpO2 mode (Red + IR), 100 sps, 18-bit ADC, FIFO polling.
 */

#include <zephyr/kernel.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/logging/log.h>

#include "max30102.h"

LOG_MODULE_REGISTER(max30102, LOG_LEVEL_INF);

/* ------------------------------------------------------------------ */
/* Register helpers                                                    */
/* ------------------------------------------------------------------ */

static int reg_write(const struct device *dev, uint8_t reg, uint8_t val)
{
	uint8_t buf[2] = { reg, val };
	return i2c_write(dev, buf, sizeof(buf), MAX30102_I2C_ADDR);
}

static int reg_read(const struct device *dev, uint8_t reg,
		    uint8_t *out, size_t len)
{
	return i2c_write_read(dev, MAX30102_I2C_ADDR, &reg, 1, out, len);
}

/* ------------------------------------------------------------------ */
/* Public API                                                          */
/* ------------------------------------------------------------------ */

int max30102_init(const struct device *dev)
{
	int ret;
	uint8_t part_id;

	if (!device_is_ready(dev)) {
		LOG_ERR("I2C device not ready");
		return -ENODEV;
	}

	ret = reg_read(dev, MAX30102_REG_PART_ID, &part_id, 1);
	if (ret < 0) {
		LOG_ERR("PART_ID read failed: %d", ret);
		return ret;
	}
	if (part_id != 0x15) {
		LOG_ERR("Wrong PART_ID: 0x%02X (want 0x15)", part_id);
		return -ENODEV;
	}
	LOG_INF("MAX30102 found (PART_ID=0x%02X)", part_id);

	/* Soft reset, then wait for it to clear */
	ret = reg_write(dev, MAX30102_REG_MODE_CONFIG, MAX30102_MODE_RESET);
	if (ret < 0) {
		return ret;
	}
	k_msleep(10);

	/* FIFO: no averaging, rollover on, almost-full at 15 */
	ret = reg_write(dev, MAX30102_REG_FIFO_CONFIG,
			MAX30102_FIFO_SMP_AVE_1 |
			MAX30102_FIFO_ROLLOVER_EN |
			MAX30102_FIFO_A_FULL_15);
	if (ret < 0) {
		return ret;
	}

	/* SpO2: 4096 nA full scale, 100 sps, 411 us pulse width */
	ret = reg_write(dev, MAX30102_REG_SPO2_CONFIG,
			MAX30102_SPO2_ADC_RGE_4096 |
			MAX30102_SPO2_SR_100 |
			MAX30102_SPO2_LED_PW_411);
	if (ret < 0) {
		return ret;
	}

	/* LED current ~7.2 mA each */
	ret = reg_write(dev, MAX30102_REG_LED1_PA, 0x24);
	if (ret < 0) {
		return ret;
	}
	ret = reg_write(dev, MAX30102_REG_LED2_PA, 0x24);
	if (ret < 0) {
		return ret;
	}

	/* SpO2 mode (Red + IR) */
	ret = reg_write(dev, MAX30102_REG_MODE_CONFIG, MAX30102_MODE_SPO2);
	if (ret < 0) {
		return ret;
	}

	/* Clear FIFO pointers */
	reg_write(dev, MAX30102_REG_FIFO_WR_PTR, 0x00);
	reg_write(dev, MAX30102_REG_OVF_COUNTER,  0x00);
	reg_write(dev, MAX30102_REG_FIFO_RD_PTR, 0x00);

	LOG_INF("MAX30102 ready");
	return 0;
}

int max30102_read_sample(const struct device *dev,
			 struct max30102_raw_sample *sample)
{
	uint8_t wr_ptr, rd_ptr;
	int ret;

	ret = reg_read(dev, MAX30102_REG_FIFO_WR_PTR, &wr_ptr, 1);
	if (ret < 0) {
		return ret;
	}
	ret = reg_read(dev, MAX30102_REG_FIFO_RD_PTR, &rd_ptr, 1);
	if (ret < 0) {
		return ret;
	}
	if (wr_ptr == rd_ptr) {
		return 0; /* FIFO empty */
	}

	/* 6 bytes per sample in SpO2 mode: 3 Red + 3 IR */
	uint8_t raw[6];
	ret = reg_read(dev, MAX30102_REG_FIFO_DATA, raw, sizeof(raw));
	if (ret < 0) {
		return ret;
	}

	sample->red = ((uint32_t)(raw[0] & 0x03) << 16) |
		      ((uint32_t)raw[1] << 8) |
		       (uint32_t)raw[2];

	sample->ir  = ((uint32_t)(raw[3] & 0x03) << 16) |
		      ((uint32_t)raw[4] << 8) |
		       (uint32_t)raw[5];
	return 1;
}

uint8_t max30102_compute_hr(const uint32_t *ir_buf, size_t count,
			    uint32_t sample_hz)
{
	if (count < 10 || sample_hz == 0) {
		return 0;
	}

	/* Remove DC baseline */
	int64_t sum = 0;
	for (size_t i = 0; i < count; i++) {
		sum += ir_buf[i];
	}
	int32_t mean = (int32_t)(sum / (int64_t)count);

	/* Count positive-to-negative zero crossings on AC signal */
	int crosses = 0;
	int32_t prev = (int32_t)ir_buf[0] - mean;
	for (size_t i = 1; i < count; i++) {
		int32_t curr = (int32_t)ir_buf[i] - mean;
		if (prev >= 0 && curr < 0) {
			crosses++;
		}
		prev = curr;
	}

	if (crosses < 2) {
		LOG_WRN("Not enough zero crossings (%d) for HR", crosses);
		return 0;
	}

	float window_sec = (float)count / (float)sample_hz;
	float bpm = ((float)crosses / window_sec) * 60.0f;

	if (bpm < 30.0f || bpm > 250.0f) {
		LOG_WRN("HR out of range: %.1f bpm", (double)bpm);
		return 0;
	}

	LOG_DBG("HR: %d crossings -> %.1f bpm", crosses, (double)bpm);
	return (uint8_t)(bpm + 0.5f);
}
