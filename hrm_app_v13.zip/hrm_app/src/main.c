/*
 * Heart Rate Monitor - main application
 * NCS v3.2.4 / nRF52-DK + MAX30102
 *
 * Uses max30102_drain_fifo() to collect all pending samples in one
 * I2C burst per poll cycle, guaranteeing the buffer fills reliably.
 */

#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/logging/log.h>
#include <string.h>

#include "../drivers/max30102/max30102.h"
#include "ble_hrs.h"

LOG_MODULE_REGISTER(main, LOG_LEVEL_INF);

#define I2C_NODE DT_NODELABEL(i2c0)

/* Poll every 500ms - at 25 sps, ~12 samples accumulate per poll */
#define POLL_INTERVAL_MS    500U

/* BLE smoothing */
#define BLE_AVG_WINDOW       5U
#define BLE_SPIKE_THRESHOLD  20U
#define BLE_MIN_QUALITY      0.01f

/* ------------------------------------------------------------------ */
/* BLE smoothing                                                       */
/* ------------------------------------------------------------------ */

static uint8_t bpm_history[BLE_AVG_WINDOW];
static uint8_t history_count;
static uint8_t history_idx;

static void history_reset(void)
{
	history_count = 0;
	history_idx   = 0;
}

static void history_add(uint8_t bpm)
{
	bpm_history[history_idx] = bpm;
	history_idx = (history_idx + 1) % BLE_AVG_WINDOW;
	if (history_count < BLE_AVG_WINDOW) {
		history_count++;
	}
}

static uint8_t history_average(void)
{
	if (history_count == 0) {
		return 0;
	}
	uint32_t sum = 0;
	for (uint8_t i = 0; i < history_count; i++) {
		sum += bpm_history[i];
	}
	return (uint8_t)((sum + history_count / 2) / history_count);
}

static uint8_t smooth_bpm(const struct max30102_hr_result *r)
{
	if (!r->finger_present || r->bpm == 0) {
		history_reset();
		return 0;
	}
	if (r->signal_quality < BLE_MIN_QUALITY) {
		LOG_WRN("Low quality (%.3f) - skipping",
			(double)r->signal_quality);
		return history_average();
	}
	if (history_count >= 2) {
		uint8_t avg = history_average();
		int diff = (int)r->bpm - (int)avg;
		if (diff < 0) { diff = -diff; }
		if (diff > BLE_SPIKE_THRESHOLD) {
			LOG_WRN("Spike rejected: %u bpm (avg=%u)",
				r->bpm, avg);
			return avg;
		}
	}
	history_add(r->bpm);
	return history_average();
}

/* ------------------------------------------------------------------ */
/* Main                                                                */
/* ------------------------------------------------------------------ */

int main(void)
{
	LOG_INF("Heart Rate Monitor starting");

	int ret = bt_hrs_init();
	if (ret) {
		LOG_ERR("BLE init failed: %d", ret);
		return ret;
	}

	const struct device *i2c_dev = DEVICE_DT_GET(I2C_NODE);
	if (!device_is_ready(i2c_dev)) {
		LOG_ERR("I2C device not ready");
		return -ENODEV;
	}

	ret = max30102_init(i2c_dev);
	if (ret) {
		LOG_ERR("MAX30102 init failed: %d", ret);
		return ret;
	}

	/* IR sample accumulation buffer */
	static uint32_t ir_buf[MAX30102_SAMPLES_PER_CALC];
	size_t n = 0;

	/* Drain buffer - sized for one full FIFO (32 samples) */
	struct max30102_raw_sample drain[32];

	LOG_INF("Running - need %u samples per window (~%u s)",
		MAX30102_SAMPLES_PER_CALC,
		MAX30102_SAMPLES_PER_CALC / MAX30102_SAMPLE_RATE_HZ);

	while (1) {
		/* Drain everything currently in the FIFO */
		int got = max30102_drain_fifo(i2c_dev, drain, 32);

		if (got < 0) {
			LOG_ERR("FIFO drain error: %d", got);
		} else if (got > 0) {
			LOG_DBG("Drained %d samples (buf %u/%u)",
				got, n, MAX30102_SAMPLES_PER_CALC);

			/* Append IR values to accumulation buffer */
			for (int i = 0; i < got; i++) {
				if (n < MAX30102_SAMPLES_PER_CALC) {
					ir_buf[n++] = drain[i].ir;
				}
			}
		}

		/* Run algorithm when buffer is full */
		if (n >= MAX30102_SAMPLES_PER_CALC) {
			struct max30102_hr_result result;

			max30102_compute_hr(ir_buf,
					    MAX30102_SAMPLES_PER_CALC,
					    MAX30102_SAMPLE_RATE_HZ,
					    &result);

			uint8_t smoothed = smooth_bpm(&result);

			if (!result.finger_present) {
				LOG_INF("No finger detected");
			} else if (smoothed == 0) {
				LOG_INF("Collecting baseline...");
			} else {
				LOG_INF("HR: %u bpm (raw=%u q=%.3f)",
					smoothed, result.bpm,
					(double)result.signal_quality);

				ret = bt_hrs_notify(smoothed);
				if (ret && ret != -ENOTCONN) {
					LOG_WRN("Notify failed: %d", ret);
				}
			}

			/* Reset for next window */
			n = 0;
		}

		k_msleep(POLL_INTERVAL_MS);
	}

	return 0;
}
