#ifndef DRIVERS_MAX30102_H_
#define DRIVERS_MAX30102_H_

#include <zephyr/device.h>
#include <stdint.h>
#include <stdbool.h>

#define MAX30102_I2C_ADDR    0x57

/* Registers */
#define MAX30102_REG_INT_STATUS1  0x00
#define MAX30102_REG_INT_STATUS2  0x01
#define MAX30102_REG_INT_ENABLE1  0x02
#define MAX30102_REG_INT_ENABLE2  0x03
#define MAX30102_REG_FIFO_WR_PTR  0x04
#define MAX30102_REG_OVF_COUNTER  0x05
#define MAX30102_REG_FIFO_RD_PTR  0x06
#define MAX30102_REG_FIFO_DATA    0x07
#define MAX30102_REG_FIFO_CONFIG  0x08
#define MAX30102_REG_MODE_CONFIG  0x09
#define MAX30102_REG_SPO2_CONFIG  0x0A
#define MAX30102_REG_LED1_PA      0x0C
#define MAX30102_REG_LED2_PA      0x0D
#define MAX30102_REG_PART_ID      0xFF

/* Mode config */
#define MAX30102_MODE_SPO2        0x03
#define MAX30102_MODE_RESET       0x40

/* FIFO config */
#define MAX30102_FIFO_SMP_AVE_4   0x40
#define MAX30102_FIFO_ROLLOVER_EN 0x10
#define MAX30102_FIFO_A_FULL_15   0x0F

/* SpO2 config */
#define MAX30102_SPO2_ADC_RGE_4096 0x20
#define MAX30102_SPO2_SR_100       0x04
#define MAX30102_SPO2_LED_PW_411   0x03

/* 25 effective sps after 4x HW averaging, 150 samples = ~6 second window */
#define MAX30102_SAMPLE_RATE_HZ    25U
#define MAX30102_SAMPLES_PER_CALC  150U

/* Signal quality thresholds */
#define MAX30102_FINGER_THRESHOLD   50000UL
#define MAX30102_QUALITY_THRESHOLD  0.005f

struct max30102_raw_sample {
	uint32_t red;
	uint32_t ir;
};

struct max30102_hr_result {
	uint8_t  bpm;
	bool     finger_present;
	float    signal_quality;
};

int  max30102_init(const struct device *dev);

/**
 * @brief Drain ALL available samples from the FIFO in one I2C burst.
 *
 * Reads WR_PTR, OVF_COUNTER, RD_PTR in a single transaction to avoid
 * race conditions, then reads all pending samples in one burst.
 *
 * @param out_buf     Output buffer (must hold at least max_samples entries).
 * @param max_samples Maximum samples to read (cap at FIFO depth = 32).
 * @return Number of samples read, or negative errno on error.
 */
int  max30102_drain_fifo(const struct device *dev,
			 struct max30102_raw_sample *out_buf,
			 uint8_t max_samples);

/* Single-sample wrapper around drain_fifo for compatibility */
int  max30102_read_sample(const struct device *dev,
			  struct max30102_raw_sample *sample);

void max30102_compute_hr(const uint32_t *ir_buf, size_t count,
			 uint32_t sample_hz,
			 struct max30102_hr_result *result);

#endif /* DRIVERS_MAX30102_H_ */
