/*
 * MAX30102 Pulse Oximeter / Heart Rate Sensor Driver
 *
 * Supports HR-only mode (Red LED) with 100 sps, 18-bit ADC.
 * Reads samples from the on-chip 32-deep FIFO over I2C.
 */

#include <zephyr/kernel.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/logging/log.h>
#include <string.h>
#include <stdlib.h>

#include "max30102.h"

LOG_MODULE_REGISTER(max30102, LOG_LEVEL_INF);

/* ------------------------------------------------------------------ */
/* Low-level register helpers                                          */
/* ------------------------------------------------------------------ */

static int reg_write(const struct device *dev, uint8_t reg, uint8_t val)
{
	uint8_t buf[2] = { reg, val };
	return i2c_write(dev, buf, sizeof(buf), MAX30102_I2C_ADDR);
}

static int reg_read(const struct device *dev, uint8_t reg,
		    uint8_t *out, size_t len)
{
	return i2c_write_read(dev, MAX30102_I2C_ADDR,
			      &reg, 1, out, len);
}

/* ------------------------------------------------------------------ */
/* Public API                                                          */
/* ------------------------------------------------------------------ */

int max30102_init(const struct device *dev)
{
	int ret;
	uint8_t part_id;

	if (!device_is_ready(dev)) {
		LOG_ERR("I2C device not ready");
		return -ENODEV;
	}

	/* Verify part ID – MAX30102 always returns 0x15 */
	ret = reg_read(dev, MAX30102_REG_PART_ID, &part_id, 1);
	if (ret < 0) {
		LOG_ERR("Failed to read PART_ID: %d", ret);
		return ret;
	}
	if (part_id != 0x15) {
		LOG_ERR("Unexpected PART_ID: 0x%02X (expected 0x15)", part_id);
		return -ENODEV;
	}
	LOG_INF("MAX30102 found (PART_ID=0x%02X)", part_id);

	/* Soft reset */
	ret = reg_write(dev, MAX30102_REG_MODE_CONFIG, MAX30102_MODE_RESET);
	if (ret < 0) {
		return ret;
	}
	k_msleep(10);   /* datasheet: wait for reset to complete */

	/* FIFO configuration:
	 *   - No sample averaging (1 sample per FIFO entry)
	 *   - FIFO rollover enabled
	 *   - Almost-full threshold: 15 unread samples remaining */
	ret = reg_write(dev, MAX30102_REG_FIFO_CONFIG,
			MAX30102_FIFO_SMP_AVE_1 |
			MAX30102_FIFO_ROLLOVER_EN |
			MAX30102_FIFO_A_FULL_15);
	if (ret < 0) {
		return ret;
	}

	/* SpO2 configuration:
	 *   - Full-scale: 4096 nA
	 *   - Sample rate: 100 sps
	 *   - LED pulse width: 411 µs (18-bit ADC resolution) */
	ret = reg_write(dev, MAX30102_REG_SPO2_CONFIG,
			MAX30102_SPO2_ADC_RGE_4096 |
			MAX30102_SPO2_SR_100 |
			MAX30102_SPO2_LED_PW_411);
	if (ret < 0) {
		return ret;
	}

	/* LED pulse amplitude – 0x24 ≈ 7.2 mA (adjust for your application) */
	ret = reg_write(dev, MAX30102_REG_LED1_PA, 0x24);   /* Red */
	if (ret < 0) {
		return ret;
	}
	ret = reg_write(dev, MAX30102_REG_LED2_PA, 0x24);   /* IR */
	if (ret < 0) {
		return ret;
	}

	/* Set mode: SpO2 (Red + IR) so we always have both channels.
	 * Switch to MAX30102_MODE_HR_ONLY if you only need Red. */
	ret = reg_write(dev, MAX30102_REG_MODE_CONFIG, MAX30102_MODE_SPO2);
	if (ret < 0) {
		return ret;
	}

	/* Clear FIFO pointers */
	reg_write(dev, MAX30102_REG_FIFO_WR_PTR, 0x00);
	reg_write(dev, MAX30102_REG_OVF_COUNTER,  0x00);
	reg_write(dev, MAX30102_REG_FIFO_RD_PTR, 0x00);

	LOG_INF("MAX30102 initialised (SpO2 mode, 100 sps, 411 µs pw)");
	return 0;
}

int max30102_read_sample(const struct device *dev,
			 struct max30102_raw_sample *sample)
{
	int ret;
	uint8_t wr_ptr, rd_ptr;

	/* Check if a sample is available */
	ret = reg_read(dev, MAX30102_REG_FIFO_WR_PTR, &wr_ptr, 1);
	if (ret < 0) {
		return ret;
	}
	ret = reg_read(dev, MAX30102_REG_FIFO_RD_PTR, &rd_ptr, 1);
	if (ret < 0) {
		return ret;
	}

	if (wr_ptr == rd_ptr) {
		return 0;   /* FIFO empty */
	}

	/*
	 * Each FIFO entry in SpO2 mode = 6 bytes:
	 *   [0..2] Red (MSB first, 18-bit value in bits 17..0)
	 *   [3..5] IR  (MSB first, 18-bit value in bits 17..0)
	 */
	uint8_t raw[6];
	ret = reg_read(dev, MAX30102_REG_FIFO_DATA, raw, sizeof(raw));
	if (ret < 0) {
		return ret;
	}

	sample->red = ((uint32_t)(raw[0] & 0x03) << 16) |
		      ((uint32_t)raw[1] << 8) |
		       (uint32_t)raw[2];

	sample->ir  = ((uint32_t)(raw[3] & 0x03) << 16) |
		      ((uint32_t)raw[4] << 8) |
		       (uint32_t)raw[5];

	return 1;
}

/* ------------------------------------------------------------------ */
/* Heart rate calculation                                              */
/*                                                                     */
/* Simple algorithm:                                                   */
/*  1. High-pass filter (remove DC baseline) using a running mean.    */
/*  2. Detect positive-to-negative zero crossings of the filtered     */
/*     signal → each crossing corresponds to one heartbeat.           */
/*  3. BPM = (crossings / 2) / window_seconds * 60                   */
/* ------------------------------------------------------------------ */

uint8_t max30102_compute_hr(const uint32_t *ir_buf, size_t count,
			    uint32_t sample_hz)
{
	if (count < 10 || sample_hz == 0) {
		return 0;
	}

	/* --- Remove DC: subtract sliding mean over the whole buffer --- */
	int32_t ac[count];
	int64_t sum = 0;

	for (size_t i = 0; i < count; i++) {
		sum += ir_buf[i];
	}
	int32_t mean = (int32_t)(sum / (int64_t)count);

	for (size_t i = 0; i < count; i++) {
		ac[i] = (int32_t)ir_buf[i] - mean;
	}

	/* --- Count zero crossings (positive → negative) --- */
	int crosses = 0;
	for (size_t i = 1; i < count; i++) {
		if (ac[i - 1] >= 0 && ac[i] < 0) {
			crosses++;
		}
	}

	if (crosses < 2) {
		LOG_WRN("HR calc: not enough crossings (%d)", crosses);
		return 0;
	}

	/* Each cardiac cycle = one positive-to-negative crossing */
	float window_sec = (float)count / (float)sample_hz;
	float bpm = ((float)crosses / window_sec) * 60.0f;

	LOG_DBG("HR: crossings=%d window=%.1fs bpm=%.1f",
		crosses, (double)window_sec, (double)bpm);

	/* Sanity check: plausible resting-to-peak heart rate */
	if (bpm < 30.0f || bpm > 250.0f) {
		LOG_WRN("HR out of range: %.1f bpm", (double)bpm);
		return 0;
	}

	return (uint8_t)(bpm + 0.5f);
}
