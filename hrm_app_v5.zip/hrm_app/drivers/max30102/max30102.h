#ifndef DRIVERS_MAX30102_H_
#define DRIVERS_MAX30102_H_

#include <zephyr/device.h>
#include <stdint.h>

/* MAX30102 I2C address */
#define MAX30102_I2C_ADDR       0x57

/* Register map */
#define MAX30102_REG_INT_STATUS1    0x00
#define MAX30102_REG_INT_STATUS2    0x01
#define MAX30102_REG_INT_ENABLE1    0x02
#define MAX30102_REG_INT_ENABLE2    0x03
#define MAX30102_REG_FIFO_WR_PTR    0x04
#define MAX30102_REG_OVF_COUNTER    0x05
#define MAX30102_REG_FIFO_RD_PTR    0x06
#define MAX30102_REG_FIFO_DATA      0x07
#define MAX30102_REG_FIFO_CONFIG    0x08
#define MAX30102_REG_MODE_CONFIG    0x09
#define MAX30102_REG_SPO2_CONFIG    0x0A
#define MAX30102_REG_LED1_PA        0x0C   /* Red LED */
#define MAX30102_REG_LED2_PA        0x0D   /* IR LED */
#define MAX30102_REG_PILOT_PA       0x10
#define MAX30102_REG_MULTI_LED1     0x11
#define MAX30102_REG_MULTI_LED2     0x12
#define MAX30102_REG_TEMP_INT       0x1F
#define MAX30102_REG_TEMP_FRAC      0x20
#define MAX30102_REG_TEMP_CONFIG    0x21
#define MAX30102_REG_PART_ID        0xFF

/* Mode config bits */
#define MAX30102_MODE_HR_ONLY       0x02   /* Heart rate mode (Red LED only) */
#define MAX30102_MODE_SPO2          0x03   /* SpO2 mode (Red + IR) */
#define MAX30102_MODE_RESET         0x40
#define MAX30102_MODE_SHDN          0x80

/* FIFO config */
#define MAX30102_FIFO_SMP_AVE_1     0x00
#define MAX30102_FIFO_SMP_AVE_2     0x20
#define MAX30102_FIFO_SMP_AVE_4     0x40
#define MAX30102_FIFO_ROLLOVER_EN   0x10
#define MAX30102_FIFO_A_FULL_15     0x0F   /* Almost full at 15 remaining */

/* SpO2 config */
#define MAX30102_SPO2_ADC_RGE_4096  0x20   /* 4096 nA full scale */
#define MAX30102_SPO2_SR_100        0x04   /* 100 samples/sec */
#define MAX30102_SPO2_LED_PW_411    0x03   /* 411 us pulse, 18-bit ADC */

/* Samples to collect per HR calculation window */
#define MAX30102_SAMPLES_PER_CALC   100

/**
 * @brief Raw sample from MAX30102 FIFO
 */
struct max30102_raw_sample {
	uint32_t red;
	uint32_t ir;
};

/**
 * @brief Initialise the MAX30102.
 *
 * @param dev  I2C device used to communicate with the sensor.
 * @return 0 on success, negative errno on failure.
 */
int max30102_init(const struct device *dev);

/**
 * @brief Read one sample (Red + IR) from the FIFO.
 *
 * @param dev    I2C device.
 * @param sample Output sample.
 * @return Number of samples read (0 or 1), or negative errno on error.
 */
int max30102_read_sample(const struct device *dev,
			 struct max30102_raw_sample *sample);

/**
 * @brief Compute heart rate from a buffer of IR samples.
 *
 * Uses a simple peak-detection algorithm on the IR channel.
 *
 * @param ir_buf    Pointer to array of IR values.
 * @param count     Number of samples in the buffer.
 * @param sample_hz Sampling rate in Hz.
 * @return Heart rate in BPM, or 0 if not calculable.
 */
uint8_t max30102_compute_hr(const uint32_t *ir_buf, size_t count,
			    uint32_t sample_hz);

#endif /* DRIVERS_MAX30102_H_ */
