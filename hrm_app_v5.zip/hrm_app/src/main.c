/*
 * Heart Rate Monitor – main application
 *
 * Flow:
 *   1. Initialise BLE and start advertising the Heart Rate Service.
 *   2. Initialise the MAX30102 sensor over I2C.
 *   3. Collect MAX30102_SAMPLES_PER_CALC samples at ~100 sps.
 *   4. Compute heart rate via peak detection on the IR channel.
 *   5. Send the result over BLE via HRS notification.
 *   6. Repeat indefinitely.
 */

#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/logging/log.h>

#include "../drivers/max30102/max30102.h"
#include "ble_hrs.h"

LOG_MODULE_REGISTER(main, LOG_LEVEL_INF);

/* ------------------------------------------------------------------ */
/* Configuration                                                       */
/* ------------------------------------------------------------------ */

#define SAMPLE_RATE_HZ      100U        /* Must match MAX30102 config   */
#define SAMPLE_INTERVAL_MS  (1000U / SAMPLE_RATE_HZ)

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

/* Retrieve the I2C bus that the MAX30102 sits on (i2c0 in the overlay) */
#define I2C_NODE DT_NODELABEL(i2c0)

int main(void)
{
	int ret;

	LOG_INF("=== Heart Rate Monitor starting ===");

	/* -------- BLE -------- */
	ret = bt_hrs_init();
	if (ret) {
		LOG_ERR("BLE HRS init failed: %d", ret);
		return ret;
	}

	/* -------- I2C / Sensor -------- */
	const struct device *i2c_dev = DEVICE_DT_GET(I2C_NODE);

	if (!device_is_ready(i2c_dev)) {
		LOG_ERR("I2C device not ready");
		return -ENODEV;
	}

	ret = max30102_init(i2c_dev);
	if (ret) {
		LOG_ERR("MAX30102 init failed: %d", ret);
		return ret;
	}

	/* -------- Sampling buffer -------- */
	uint32_t ir_buf[MAX30102_SAMPLES_PER_CALC];
	size_t   n = 0;

	LOG_INF("Sampling at %u Hz, HR window = %u samples (~%u s)",
		SAMPLE_RATE_HZ,
		MAX30102_SAMPLES_PER_CALC,
		MAX30102_SAMPLES_PER_CALC / SAMPLE_RATE_HZ);

	/* -------- Main loop -------- */
	while (1) {
		struct max30102_raw_sample s;
		int got = max30102_read_sample(i2c_dev, &s);

		if (got == 1) {
			ir_buf[n++] = s.ir;

			if (n >= MAX30102_SAMPLES_PER_CALC) {
				/* Compute heart rate */
				uint8_t bpm = max30102_compute_hr(
					ir_buf,
					MAX30102_SAMPLES_PER_CALC,
					SAMPLE_RATE_HZ);

				if (bpm > 0) {
					LOG_INF("Heart rate: %u bpm", bpm);

					ret = bt_hrs_notify(bpm);
					if (ret == -ENOTCONN) {
						LOG_DBG("No BLE peer connected yet");
					} else if (ret < 0) {
						LOG_WRN("BLE notify failed: %d", ret);
					}
				} else {
					LOG_WRN("Could not compute HR – check sensor contact");
				}

				/* Reset buffer for the next window */
				n = 0;
			}
		} else if (got < 0) {
			LOG_ERR("Sensor read error: %d", got);
		}
		/* got == 0: FIFO empty, just wait */

		k_msleep(SAMPLE_INTERVAL_MS);
	}

	return 0;
}
