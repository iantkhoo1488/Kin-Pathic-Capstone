#ifndef BLE_HRS_H_
#define BLE_HRS_H_

#include <stdint.h>

/**
 * @brief Initialise the BLE stack and start advertising the
 *        Heart Rate Service (HRS).
 *
 * Call once at startup before bt_hrs_notify().
 *
 * @return 0 on success, negative errno on failure.
 */
int bt_hrs_init(void);

/**
 * @brief Notify a connected peer of a new heart rate measurement.
 *
 * @param bpm  Heart rate value in beats per minute (0–255).
 * @return 0 on success, -ENOTCONN if no peer is subscribed,
 *         or another negative errno on failure.
 */
int bt_hrs_notify(uint8_t bpm);

#endif /* BLE_HRS_H_ */
