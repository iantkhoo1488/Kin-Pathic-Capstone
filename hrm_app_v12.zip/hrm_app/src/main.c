/*
 * Heart Rate Monitor - main application
 * NCS v3.2.4 / nRF52-DK + MAX30102
 *
 * Key fix: drain ALL available FIFO samples each poll cycle instead
 * of one at a time. At 25 Hz effective rate the FIFO accumulates
 * several samples between polls — reading only one left the buffer
 * perpetually empty and the window never filled.
 */

#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/logging/log.h>
#include <string.h>

#include "../drivers/max30102/max30102.h"
#include "ble_hrs.h"

LOG_MODULE_REGISTER(main, LOG_LEVEL_INF);

#define I2C_NODE DT_NODELABEL(i2c0)

/*
 * Poll every 200ms and drain all FIFO samples each time.
 * At 25 Hz effective rate, ~5 samples accumulate per 200ms poll.
 * This is far more reliable than tight 40ms single-sample polling.
 */
#define POLL_INTERVAL_MS     200U

/* Max samples to drain per poll (FIFO depth is 32) */
#define MAX_DRAIN_PER_POLL   32U

/* BLE smoothing */
#define BLE_AVG_WINDOW        5U
#define BLE_SPIKE_THRESHOLD   20U
#define BLE_MIN_QUALITY       0.01f

/* ------------------------------------------------------------------ */
/* BLE smoothing                                                       */
/* ------------------------------------------------------------------ */

static uint8_t bpm_history[BLE_AVG_WINDOW];
static uint8_t history_count;
static uint8_t history_idx;

static void history_reset(void)
{
	history_count = 0;
	history_idx   = 0;
}

static void history_add(uint8_t bpm)
{
	bpm_history[history_idx] = bpm;
	history_idx = (history_idx + 1) % BLE_AVG_WINDOW;
	if (history_count < BLE_AVG_WINDOW) {
		history_count++;
	}
}

static uint8_t history_average(void)
{
	if (history_count == 0) {
		return 0;
	}
	uint32_t sum = 0;
	for (uint8_t i = 0; i < history_count; i++) {
		sum += bpm_history[i];
	}
	return (uint8_t)((sum + history_count / 2) / history_count);
}

static uint8_t smooth_bpm(const struct max30102_hr_result *r)
{
	if (!r->finger_present || r->bpm == 0) {
		history_reset();
		return 0;
	}
	if (r->signal_quality < BLE_MIN_QUALITY) {
		LOG_WRN("Low quality (%.3f) - skipping",
			(double)r->signal_quality);
		return history_average();
	}
	if (history_count >= 2) {
		uint8_t avg = history_average();
		int diff = (int)r->bpm - (int)avg;
		if (diff < 0) {
			diff = -diff;
		}
		if (diff > BLE_SPIKE_THRESHOLD) {
			LOG_WRN("Spike rejected: %u bpm (avg=%u)",
				r->bpm, avg);
			return avg;
		}
	}
	history_add(r->bpm);
	return history_average();
}

/* ------------------------------------------------------------------ */
/* Main                                                                */
/* ------------------------------------------------------------------ */

int main(void)
{
	LOG_INF("Heart Rate Monitor starting");

	int ret = bt_hrs_init();
	if (ret) {
		LOG_ERR("BLE init failed: %d", ret);
		return ret;
	}

	const struct device *i2c_dev = DEVICE_DT_GET(I2C_NODE);
	if (!device_is_ready(i2c_dev)) {
		LOG_ERR("I2C device not ready");
		return -ENODEV;
	}

	ret = max30102_init(i2c_dev);
	if (ret) {
		LOG_ERR("MAX30102 init failed: %d", ret);
		return ret;
	}

	static uint32_t ir_buf[MAX30102_SAMPLES_PER_CALC];
	size_t n = 0;

	LOG_INF("Running - collecting %u samples per window",
		MAX30102_SAMPLES_PER_CALC);

	while (1) {
		/* Drain ALL available samples from the FIFO this poll */
		for (uint8_t d = 0; d < MAX_DRAIN_PER_POLL; d++) {
			struct max30102_raw_sample s;
			int got = max30102_read_sample(i2c_dev, &s);

			if (got == 0) {
				/* FIFO empty - stop draining */
				break;
			} else if (got < 0) {
				LOG_ERR("Sensor read error: %d", got);
				break;
			}

			/* got == 1: store sample */
			if (n < MAX30102_SAMPLES_PER_CALC) {
				ir_buf[n++] = s.ir;
			}
		}

		LOG_DBG("Buffer: %u / %u samples",
			n, MAX30102_SAMPLES_PER_CALC);

		/* Run algorithm once buffer is full */
		if (n >= MAX30102_SAMPLES_PER_CALC) {
			struct max30102_hr_result result;

			max30102_compute_hr(ir_buf,
					    MAX30102_SAMPLES_PER_CALC,
					    MAX30102_SAMPLE_RATE_HZ,
					    &result);

			uint8_t smoothed = smooth_bpm(&result);

			if (!result.finger_present) {
				LOG_INF("No finger detected");
			} else if (smoothed == 0) {
				LOG_INF("Collecting baseline...");
			} else {
				LOG_INF("HR: %u bpm (raw=%u q=%.3f)",
					smoothed, result.bpm,
					(double)result.signal_quality);

				ret = bt_hrs_notify(smoothed);
				if (ret && ret != -ENOTCONN) {
					LOG_WRN("Notify failed: %d", ret);
				}
			}

			/* Reset for next window */
			n = 0;
		}

		k_msleep(POLL_INTERVAL_MS);
	}

	return 0;
}
