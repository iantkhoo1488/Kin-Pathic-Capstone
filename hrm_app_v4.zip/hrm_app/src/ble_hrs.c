/*
 * Bluetooth Heart Rate Service (HRS)
 *
 * Implements the standard GATT Heart Rate Service (UUID 0x180D) with:
 *   - Heart Rate Measurement characteristic (0x2A37)  – notify
 *   - Body Sensor Location characteristic  (0x2A38)  – read (Wrist)
 *   - Heart Rate Control Point             (0x2A39)  – write
 *
 * Advertises as "HRM_nRF52" so it appears clearly on the central device.
 */

#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/hci.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>
#include <zephyr/logging/log.h>
#include <zephyr/kernel.h>

#include "ble_hrs.h"

LOG_MODULE_REGISTER(ble_hrs, LOG_LEVEL_INF);

/* ------------------------------------------------------------------ */
/* State                                                               */
/* ------------------------------------------------------------------ */

static struct bt_conn *current_conn;
static bool            hrs_notify_enabled;

/* ------------------------------------------------------------------ */
/* Callbacks                                                           */
/* ------------------------------------------------------------------ */

static void hrm_ccc_cfg_changed(const struct bt_gatt_attr *attr, uint16_t value)
{
	hrs_notify_enabled = (value == BT_GATT_CCC_NOTIFY);
	LOG_INF("HRS notifications %s", hrs_notify_enabled ? "enabled" : "disabled");
}

static void connected(struct bt_conn *conn, uint8_t err)
{
	if (err) {
		LOG_ERR("Connection failed (err 0x%02x)", err);
		return;
	}
	LOG_INF("Connected");
	current_conn = bt_conn_ref(conn);
}

static void disconnected(struct bt_conn *conn, uint8_t reason)
{
	LOG_INF("Disconnected (reason 0x%02x)", reason);
	if (current_conn) {
		bt_conn_unref(current_conn);
		current_conn = NULL;
	}
	hrs_notify_enabled = false;

	/* Restart advertising so a new central can connect */
	int ret = bt_le_adv_start(BT_LE_ADV_CONN_ONE_TIME,
				  ad, ARRAY_SIZE(ad), sd, ARRAY_SIZE(sd));
	if (ret) {
		LOG_ERR("Advertising restart failed: %d", ret);
	}
}

static struct bt_conn_cb conn_callbacks = {
	.connected    = connected,
	.disconnected = disconnected,
};

/* ------------------------------------------------------------------ */
/* GATT Service definition                                             */
/* ------------------------------------------------------------------ */

/* Body Sensor Location read handler – reports "Wrist" (0x02) */
static ssize_t read_bsl(struct bt_conn *conn,
			const struct bt_gatt_attr *attr,
			void *buf, uint16_t len, uint16_t offset)
{
	uint8_t bsl = 0x02;   /* Wrist */
	return bt_gatt_attr_read(conn, attr, buf, len, offset, &bsl, sizeof(bsl));
}

/* Heart Rate Control Point write handler */
static ssize_t write_hrcp(struct bt_conn *conn,
			  const struct bt_gatt_attr *attr,
			  const void *buf, uint16_t len,
			  uint16_t offset, uint8_t flags)
{
	if (len != 1) {
		return BT_GATT_ERR(BT_ATT_ERR_INVALID_ATTRIBUTE_LEN);
	}
	uint8_t cmd = *((const uint8_t *)buf);
	if (cmd == 0x01) {
		LOG_INF("HRCP: Energy Expended reset requested");
	} else {
		return BT_GATT_ERR(BT_ATT_ERR_NOT_SUPPORTED);
	}
	return len;
}

/* Service declaration */
BT_GATT_SERVICE_DEFINE(hrs_svc,
	BT_GATT_PRIMARY_SERVICE(BT_UUID_HRS),

	/* Heart Rate Measurement – notify only */
	BT_GATT_CHARACTERISTIC(BT_UUID_HRS_MEASUREMENT,
			       BT_GATT_CHRC_NOTIFY,
			       BT_GATT_PERM_NONE,
			       NULL, NULL, NULL),
	BT_GATT_CCC(hrm_ccc_cfg_changed,
		    BT_GATT_PERM_READ | BT_GATT_PERM_WRITE),

	/* Body Sensor Location – read only */
	BT_GATT_CHARACTERISTIC(BT_UUID_HRS_BODY_SENSOR,
			       BT_GATT_CHRC_READ,
			       BT_GATT_PERM_READ,
			       read_bsl, NULL, NULL),

	/* Heart Rate Control Point – write only */
	BT_GATT_CHARACTERISTIC(BT_UUID_HRS_CONTROL_POINT,
			       BT_GATT_CHRC_WRITE,
			       BT_GATT_PERM_WRITE,
			       NULL, write_hrcp, NULL),
);

/* ------------------------------------------------------------------ */
/* Advertising data                                                    */
/* ------------------------------------------------------------------ */

static const struct bt_data ad[] = {
	BT_DATA_BYTES(BT_DATA_FLAGS,
		      BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR),
	BT_DATA_BYTES(BT_DATA_UUID16_ALL,
		      BT_UUID_16_ENCODE(BT_UUID_HRS_VAL)),
};

static const struct bt_data sd[] = {
	BT_DATA(BT_DATA_NAME_COMPLETE, CONFIG_BT_DEVICE_NAME,
		sizeof(CONFIG_BT_DEVICE_NAME) - 1),
};

/* ------------------------------------------------------------------ */
/* Public API                                                          */
/* ------------------------------------------------------------------ */

int bt_hrs_init(void)
{
	int ret;

	ret = bt_enable(NULL);
	if (ret) {
		LOG_ERR("bt_enable failed: %d", ret);
		return ret;
	}

	bt_conn_cb_register(&conn_callbacks);

	ret = bt_le_adv_start(BT_LE_ADV_CONN_ONE_TIME, ad, ARRAY_SIZE(ad),
			      sd, ARRAY_SIZE(sd));
	if (ret) {
		LOG_ERR("Advertising start failed: %d", ret);
		return ret;
	}

	LOG_INF("BLE HRS advertising as \"HRM_nRF52\"");
	return 0;
}

int bt_hrs_notify(uint8_t bpm)
{
	if (!hrs_notify_enabled || !current_conn) {
		return -ENOTCONN;
	}

	/*
	 * Heart Rate Measurement value format (flags byte + 1-byte HR):
	 *   Bit 0 = 0  → HR value is UINT8
	 *   Bits 1-4   → other optional fields (not used here)
	 */
	uint8_t hrm[2] = {
		0x00,   /* flags: 8-bit HR, no EE, no RR */
		bpm,
	};

	/* Notify via the first characteristic attribute after the service */
	return bt_gatt_notify(current_conn, &hrs_svc.attrs[1], hrm, sizeof(hrm));
}
