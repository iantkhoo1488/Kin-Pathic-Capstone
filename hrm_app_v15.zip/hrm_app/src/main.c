/*
 * Heart Rate Monitor - main application
 * NCS v3.2.4 / nRF52-DK + MAX30102
 *
 * Onboard LED status indicators (active LOW on nRF52-DK):
 *   LED1 (P0.17) - Power ON      : on solid as soon as firmware boots
 *   LED2 (P0.18) - Waiting BLE   : blinks while advertising, off when connected
 *   LED3 (P0.19) - BLE Paired    : on solid when a central is connected
 *   LED4 (P0.20) - Sending data  : flashes briefly each time HR is notified
 */

#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/logging/log.h>

#include "../drivers/max30102/max30102.h"
#include "ble_hrs.h"

LOG_MODULE_REGISTER(main, LOG_LEVEL_INF);

#define I2C_NODE         DT_NODELABEL(i2c0)
#define POLL_INTERVAL_MS 500U

/* ------------------------------------------------------------------ */
/* LED definitions (active LOW — set 0 to turn ON, 1 to turn OFF)    */
/* ------------------------------------------------------------------ */

#define LED_PORT        "GPIO_0"
#define LED1_PIN        17   /* Power ON      */
#define LED2_PIN        18   /* Waiting BLE   */
#define LED3_PIN        19   /* BLE Paired    */
#define LED4_PIN        20   /* Sending data  */

#define LED_ON   0
#define LED_OFF  1

static const struct device *gpio0;

static void leds_init(void)
{
	gpio0 = device_get_binding(LED_PORT);

	gpio_pin_configure(gpio0, LED1_PIN, GPIO_OUTPUT | GPIO_ACTIVE_LOW);
	gpio_pin_configure(gpio0, LED2_PIN, GPIO_OUTPUT | GPIO_ACTIVE_LOW);
	gpio_pin_configure(gpio0, LED3_PIN, GPIO_OUTPUT | GPIO_ACTIVE_LOW);
	gpio_pin_configure(gpio0, LED4_PIN, GPIO_OUTPUT | GPIO_ACTIVE_LOW);

	/* Start: power on, all others off */
	gpio_pin_set(gpio0, LED1_PIN, 1);  /* LED1 ON  - power */
	gpio_pin_set(gpio0, LED2_PIN, 0);  /* LED2 OFF */
	gpio_pin_set(gpio0, LED3_PIN, 0);  /* LED3 OFF */
	gpio_pin_set(gpio0, LED4_PIN, 0);  /* LED4 OFF */
}

static void led_set(uint8_t pin, bool on)
{
	gpio_pin_set(gpio0, pin, on ? 1 : 0);
}

/* Brief flash on LED4 to indicate a successful BLE notification */
static void led_flash_tx(void)
{
	led_set(LED4_PIN, true);
	k_msleep(80);
	led_set(LED4_PIN, false);
}

/* ------------------------------------------------------------------ */
/* BLE advertising blink thread                                        */
/*                                                                     */
/* Runs in the background and blinks LED2 at 1 Hz while not           */
/* connected, turns it off and lights LED3 when connected.            */
/* ------------------------------------------------------------------ */

#define BLE_BLINK_STACK_SIZE 512
#define BLE_BLINK_PRIORITY   5

static void ble_blink_thread(void *a, void *b, void *c)
{
	bool led2_state = false;

	while (1) {
		if (bt_hrs_is_connected()) {
			/* Connected: LED2 off, LED3 on */
			led_set(LED2_PIN, false);
			led_set(LED3_PIN, true);
			k_msleep(200);
		} else {
			/* Advertising: blink LED2, LED3 off */
			led_set(LED3_PIN, false);
			led2_state = !led2_state;
			led_set(LED2_PIN, led2_state);
			k_msleep(500);
		}
	}
}

K_THREAD_DEFINE(ble_blink_tid,
		BLE_BLINK_STACK_SIZE,
		ble_blink_thread,
		NULL, NULL, NULL,
		BLE_BLINK_PRIORITY, 0, 0);

/* ------------------------------------------------------------------ */
/* Main                                                                */
/* ------------------------------------------------------------------ */

int main(void)
{
	LOG_INF("Heart Rate Monitor starting");

	/* LEDs first so LED1 lights immediately on boot */
	leds_init();
	LOG_INF("LEDs initialised");

	int ret = bt_hrs_init();
	if (ret) {
		LOG_ERR("BLE init failed: %d", ret);
		return ret;
	}

	const struct device *i2c_dev = DEVICE_DT_GET(I2C_NODE);
	if (!device_is_ready(i2c_dev)) {
		LOG_ERR("I2C device not ready");
		return -ENODEV;
	}

	ret = max30102_init(i2c_dev);
	if (ret) {
		LOG_ERR("MAX30102 init failed: %d", ret);
		return ret;
	}

	static uint32_t ir_buf[MAX30102_SAMPLES_PER_CALC];
	static struct max30102_raw_sample drain[32];
	size_t n = 0;

	LOG_INF("Running - window=%u samples", MAX30102_SAMPLES_PER_CALC);

	while (1) {
		/* Drain all pending FIFO samples */
		int got = max30102_drain_fifo(i2c_dev, drain, 32);

		if (got < 0) {
			LOG_ERR("FIFO drain error: %d", got);
		} else {
			for (int i = 0; i < got &&
			     n < MAX30102_SAMPLES_PER_CALC; i++) {
				ir_buf[n++] = drain[i].ir;
			}
			LOG_DBG("Drained %d, buf %u/%u", got, n,
				MAX30102_SAMPLES_PER_CALC);
		}

		/* Calculate and send when window is full */
		if (n >= MAX30102_SAMPLES_PER_CALC) {
			uint8_t bpm = max30102_compute_hr(
				ir_buf,
				MAX30102_SAMPLES_PER_CALC,
				MAX30102_SAMPLE_RATE_HZ);

			if (bpm > 0) {
				LOG_INF("Sending HR: %u bpm", bpm);
				ret = bt_hrs_notify(bpm);
				if (ret == 0) {
					/* Flash LED4 to show data was sent */
					led_flash_tx();
				} else if (ret != -ENOTCONN) {
					LOG_WRN("Notify failed: %d", ret);
				}
			} else {
				LOG_INF("No valid HR this window");
			}

			n = 0;
		}

		k_msleep(POLL_INTERVAL_MS);
	}

	return 0;
}
