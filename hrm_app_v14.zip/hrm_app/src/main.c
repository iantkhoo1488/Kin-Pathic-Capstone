/*
 * Heart Rate Monitor - main application
 * NCS v3.2.4 / nRF52-DK + MAX30102
 *
 * Always-on: no finger detection, no quality gating.
 * Drains FIFO every 500ms, runs HR algorithm when buffer is full,
 * sends BLE notification every window regardless of reading.
 */

#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/logging/log.h>

#include "../drivers/max30102/max30102.h"
#include "ble_hrs.h"

LOG_MODULE_REGISTER(main, LOG_LEVEL_INF);

#define I2C_NODE         DT_NODELABEL(i2c0)
#define POLL_INTERVAL_MS 500U

int main(void)
{
	LOG_INF("Heart Rate Monitor starting");

	int ret = bt_hrs_init();
	if (ret) {
		LOG_ERR("BLE init failed: %d", ret);
		return ret;
	}

	const struct device *i2c_dev = DEVICE_DT_GET(I2C_NODE);
	if (!device_is_ready(i2c_dev)) {
		LOG_ERR("I2C device not ready");
		return -ENODEV;
	}

	ret = max30102_init(i2c_dev);
	if (ret) {
		LOG_ERR("MAX30102 init failed: %d", ret);
		return ret;
	}

	static uint32_t ir_buf[MAX30102_SAMPLES_PER_CALC];
	static struct max30102_raw_sample drain[32];
	size_t n = 0;

	LOG_INF("Running - window=%u samples", MAX30102_SAMPLES_PER_CALC);

	while (1) {
		/* Drain all pending FIFO samples */
		int got = max30102_drain_fifo(i2c_dev, drain, 32);

		if (got < 0) {
			LOG_ERR("FIFO drain error: %d", got);
		} else {
			for (int i = 0; i < got && n < MAX30102_SAMPLES_PER_CALC; i++) {
				ir_buf[n++] = drain[i].ir;
			}
			LOG_DBG("Drained %d, buf %u/%u", got, n,
				MAX30102_SAMPLES_PER_CALC);
		}

		/* Calculate and send whenever the window is full */
		if (n >= MAX30102_SAMPLES_PER_CALC) {
			uint8_t bpm = max30102_compute_hr(
				ir_buf,
				MAX30102_SAMPLES_PER_CALC,
				MAX30102_SAMPLE_RATE_HZ);

			if (bpm > 0) {
				LOG_INF("Sending HR: %u bpm", bpm);
				ret = bt_hrs_notify(bpm);
				if (ret && ret != -ENOTCONN) {
					LOG_WRN("Notify failed: %d", ret);
				}
			} else {
				LOG_INF("No valid HR this window");
			}

			n = 0;
		}

		k_msleep(POLL_INTERVAL_MS);
	}

	return 0;
}
