/*
 * Heart Rate Monitor - main application
 * NCS v3.2.4 / nRF52-DK + MAX30102
 *
 * Onboard LED status indicators (active LOW on nRF52-DK):
 *   LED1 (P0.17) - Power ON      : on solid as soon as firmware boots
 *   LED2 (P0.18) - Waiting BLE   : blinks while advertising, off when connected
 *   LED3 (P0.19) - BLE Paired    : on solid when a central is connected
 *   LED4 (P0.20) - Sending data  : flashes briefly each time HR is notified
 *
 * Uses DT_ALIAS for LEDs which is the correct NCS v2+ approach.
 * The nRF52-DK board file defines led0..led3 aliases automatically.
 */

#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/logging/log.h>

#include "../drivers/max30102/max30102.h"
#include "ble_hrs.h"

LOG_MODULE_REGISTER(main, LOG_LEVEL_INF);

#define I2C_NODE         DT_NODELABEL(i2c0)
#define POLL_INTERVAL_MS 500U

/* ------------------------------------------------------------------ */
/* LEDs via devicetree aliases                                         */
/* The nRF52-DK board DTS defines led0=P0.17, led1=P0.18,            */
/* led2=P0.19, led3=P0.20 — all active LOW.                          */
/* ------------------------------------------------------------------ */

static const struct gpio_dt_spec led_power  = GPIO_DT_SPEC_GET(DT_ALIAS(led0), gpios);
static const struct gpio_dt_spec led_wait   = GPIO_DT_SPEC_GET(DT_ALIAS(led1), gpios);
static const struct gpio_dt_spec led_paired = GPIO_DT_SPEC_GET(DT_ALIAS(led2), gpios);
static const struct gpio_dt_spec led_tx     = GPIO_DT_SPEC_GET(DT_ALIAS(led3), gpios);

static int leds_init(void)
{
	int ret;

	if (!gpio_is_ready_dt(&led_power) ||
	    !gpio_is_ready_dt(&led_wait)  ||
	    !gpio_is_ready_dt(&led_paired)||
	    !gpio_is_ready_dt(&led_tx)) {
		LOG_ERR("LED GPIO not ready");
		return -ENODEV;
	}

	ret = gpio_pin_configure_dt(&led_power,  GPIO_OUTPUT_INACTIVE);
	if (ret < 0) { return ret; }
	ret = gpio_pin_configure_dt(&led_wait,   GPIO_OUTPUT_INACTIVE);
	if (ret < 0) { return ret; }
	ret = gpio_pin_configure_dt(&led_paired, GPIO_OUTPUT_INACTIVE);
	if (ret < 0) { return ret; }
	ret = gpio_pin_configure_dt(&led_tx,     GPIO_OUTPUT_INACTIVE);
	if (ret < 0) { return ret; }

	/* LED1 on immediately - power indicator */
	gpio_pin_set_dt(&led_power, 1);

	LOG_INF("LEDs ready");
	return 0;
}

static void led_flash_tx(void)
{
	gpio_pin_set_dt(&led_tx, 1);
	k_msleep(80);
	gpio_pin_set_dt(&led_tx, 0);
}

/* ------------------------------------------------------------------ */
/* BLE status blink thread                                             */
/* ------------------------------------------------------------------ */

#define BLE_BLINK_STACK_SIZE 512
#define BLE_BLINK_PRIORITY   5

static void ble_blink_thread(void *a, void *b, void *c)
{
	bool blink_state = false;

	while (1) {
		if (bt_hrs_is_connected()) {
			/* Connected: LED2 off, LED3 solid on */
			gpio_pin_set_dt(&led_wait,   0);
			gpio_pin_set_dt(&led_paired, 1);
			k_msleep(200);
		} else {
			/* Advertising: LED3 off, LED2 blinks */
			gpio_pin_set_dt(&led_paired, 0);
			blink_state = !blink_state;
			gpio_pin_set_dt(&led_wait, blink_state ? 1 : 0);
			k_msleep(500);
		}
	}
}

K_THREAD_DEFINE(ble_blink_tid,
		BLE_BLINK_STACK_SIZE,
		ble_blink_thread,
		NULL, NULL, NULL,
		BLE_BLINK_PRIORITY, 0, 0);

/* ------------------------------------------------------------------ */
/* Main                                                                */
/* ------------------------------------------------------------------ */

int main(void)
{
	LOG_INF("Heart Rate Monitor starting");

	int ret = leds_init();
	if (ret) {
		LOG_ERR("LED init failed: %d", ret);
		return ret;
	}

	ret = bt_hrs_init();
	if (ret) {
		LOG_ERR("BLE init failed: %d", ret);
		return ret;
	}

	const struct device *i2c_dev = DEVICE_DT_GET(I2C_NODE);
	if (!device_is_ready(i2c_dev)) {
		LOG_ERR("I2C device not ready");
		return -ENODEV;
	}

	ret = max30102_init(i2c_dev);
	if (ret) {
		LOG_ERR("MAX30102 init failed: %d", ret);
		return ret;
	}

	static uint32_t ir_buf[MAX30102_SAMPLES_PER_CALC];
	static struct max30102_raw_sample drain[32];
	size_t n = 0;

	LOG_INF("Running - window=%u samples", MAX30102_SAMPLES_PER_CALC);

	while (1) {
		int got = max30102_drain_fifo(i2c_dev, drain, 32);

		if (got < 0) {
			LOG_ERR("FIFO drain error: %d", got);
		} else {
			for (int i = 0; i < got &&
			     n < MAX30102_SAMPLES_PER_CALC; i++) {
				ir_buf[n++] = drain[i].ir;
			}
			LOG_DBG("Drained %d, buf %u/%u", got, n,
				MAX30102_SAMPLES_PER_CALC);
		}

		if (n >= MAX30102_SAMPLES_PER_CALC) {
			uint8_t bpm = max30102_compute_hr(
				ir_buf,
				MAX30102_SAMPLES_PER_CALC,
				MAX30102_SAMPLE_RATE_HZ);

			if (bpm > 0) {
				LOG_INF("Sending HR: %u bpm", bpm);
				ret = bt_hrs_notify(bpm);
				if (ret == 0) {
					led_flash_tx();
				} else if (ret != -ENOTCONN) {
					LOG_WRN("Notify failed: %d", ret);
				}
			} else {
				LOG_INF("No valid HR this window");
			}

			n = 0;
		}

		k_msleep(POLL_INTERVAL_MS);
	}

	return 0;
}
