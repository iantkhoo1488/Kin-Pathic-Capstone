#ifndef BLE_HRS_H_
#define BLE_HRS_H_

#include <stdint.h>
#include <stdbool.h>

/**
 * @brief Initialise BLE stack and start advertising the Heart Rate Service.
 * @return 0 on success, negative errno on failure.
 */
int bt_hrs_init(void);

/**
 * @brief Send a heart rate notification to the connected peer.
 * @param bpm  Heart rate in beats per minute.
 * @return 0 on success, -ENOTCONN if nobody is subscribed.
 */
int bt_hrs_notify(uint8_t bpm);

/**
 * @brief Returns true if a central is currently connected.
 */
bool bt_hrs_is_connected(void);

#endif /* BLE_HRS_H_ */
