/*
 * MAX30102 driver - NCS v3.2.4
 * Always-on mode: no finger detection, no quality gating.
 * Burst-drains FIFO in single I2C transaction each poll.
 */

#include <zephyr/kernel.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/logging/log.h>
#include <math.h>

#include "max30102.h"

LOG_MODULE_REGISTER(max30102, LOG_LEVEL_INF);

#define FIFO_DEPTH   32U
#define MWI_WIDTH     8U
#define REFRACTORY    7U
#define MAX_PEAKS    20U

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

static int reg_write(const struct device *dev, uint8_t reg, uint8_t val)
{
	uint8_t buf[2] = { reg, val };
	return i2c_write(dev, buf, sizeof(buf), MAX30102_I2C_ADDR);
}

static int reg_read(const struct device *dev, uint8_t reg,
		    uint8_t *out, size_t len)
{
	return i2c_write_read(dev, MAX30102_I2C_ADDR, &reg, 1, out, len);
}

/* ------------------------------------------------------------------ */
/* Init                                                                */
/* ------------------------------------------------------------------ */

int max30102_init(const struct device *dev)
{
	int ret;
	uint8_t part_id;

	if (!device_is_ready(dev)) {
		LOG_ERR("I2C device not ready");
		return -ENODEV;
	}

	ret = reg_read(dev, MAX30102_REG_PART_ID, &part_id, 1);
	if (ret < 0) {
		LOG_ERR("PART_ID read failed: %d", ret);
		return ret;
	}
	if (part_id != 0x15) {
		LOG_ERR("Wrong PART_ID: 0x%02X (want 0x15)", part_id);
		return -ENODEV;
	}
	LOG_INF("MAX30102 found (PART_ID=0x%02X)", part_id);

	ret = reg_write(dev, MAX30102_REG_MODE_CONFIG, MAX30102_MODE_RESET);
	if (ret < 0) { return ret; }
	k_msleep(10);

	ret = reg_write(dev, MAX30102_REG_FIFO_CONFIG,
			MAX30102_FIFO_SMP_AVE_4 |
			MAX30102_FIFO_ROLLOVER_EN |
			MAX30102_FIFO_A_FULL_15);
	if (ret < 0) { return ret; }

	ret = reg_write(dev, MAX30102_REG_SPO2_CONFIG,
			MAX30102_SPO2_ADC_RGE_4096 |
			MAX30102_SPO2_SR_100 |
			MAX30102_SPO2_LED_PW_411);
	if (ret < 0) { return ret; }

	ret = reg_write(dev, MAX30102_REG_LED1_PA, 0x24);
	if (ret < 0) { return ret; }
	ret = reg_write(dev, MAX30102_REG_LED2_PA, 0x24);
	if (ret < 0) { return ret; }

	ret = reg_write(dev, MAX30102_REG_MODE_CONFIG, MAX30102_MODE_SPO2);
	if (ret < 0) { return ret; }

	reg_write(dev, MAX30102_REG_FIFO_WR_PTR, 0x00);
	reg_write(dev, MAX30102_REG_OVF_COUNTER,  0x00);
	reg_write(dev, MAX30102_REG_FIFO_RD_PTR, 0x00);

	LOG_INF("MAX30102 ready");
	return 0;
}

/* ------------------------------------------------------------------ */
/* FIFO burst drain                                                    */
/* ------------------------------------------------------------------ */

int max30102_drain_fifo(const struct device *dev,
			struct max30102_raw_sample *out_buf,
			uint8_t max_samples)
{
	/* Read all three FIFO pointer registers in one transaction */
	uint8_t ptrs[3];
	int ret = reg_read(dev, MAX30102_REG_FIFO_WR_PTR, ptrs, 3);
	if (ret < 0) {
		return ret;
	}

	uint8_t wr_ptr = ptrs[0] & 0x1F;
	uint8_t rd_ptr = ptrs[2] & 0x1F;

	uint8_t num_samples = (wr_ptr >= rd_ptr)
		? (wr_ptr - rd_ptr)
		: (FIFO_DEPTH - rd_ptr + wr_ptr);

	if (num_samples == 0) {
		return 0;
	}
	if (num_samples > max_samples) {
		num_samples = max_samples;
	}

	/* Burst read all samples in one transaction (6 bytes each) */
	uint8_t raw[FIFO_DEPTH * 6];
	ret = reg_read(dev, MAX30102_REG_FIFO_DATA, raw, num_samples * 6U);
	if (ret < 0) {
		return ret;
	}

	for (uint8_t i = 0; i < num_samples; i++) {
		uint8_t *p = &raw[i * 6];
		out_buf[i].red = ((uint32_t)(p[0] & 0x03) << 16) |
				 ((uint32_t)p[1] << 8) | p[2];
		out_buf[i].ir  = ((uint32_t)(p[3] & 0x03) << 16) |
				 ((uint32_t)p[4] << 8) | p[5];
	}

	return num_samples;
}

/* ------------------------------------------------------------------ */
/* HR algorithm - always returns a value, no gating                   */
/* ------------------------------------------------------------------ */

uint8_t max30102_compute_hr(const uint32_t *ir_buf, size_t count,
			    uint32_t sample_hz)
{
	if (count < 10 || sample_hz == 0) {
		return 0;
	}

	/* DC removal */
	int64_t sum = 0;
	for (size_t i = 0; i < count; i++) {
		sum += ir_buf[i];
	}
	float dc_mean = (float)sum / (float)count;

	static float ac[MAX30102_SAMPLES_PER_CALC];
	if (count > MAX30102_SAMPLES_PER_CALC) {
		count = MAX30102_SAMPLES_PER_CALC;
	}
	for (size_t i = 0; i < count; i++) {
		ac[i] = (float)ir_buf[i] - dc_mean;
	}

	/* Derivative → square → moving-window integration */
	static float deriv[MAX30102_SAMPLES_PER_CALC];
	static float sq[MAX30102_SAMPLES_PER_CALC];
	static float mwi[MAX30102_SAMPLES_PER_CALC];

	deriv[0] = 0.0f;
	for (size_t i = 1; i < count; i++) {
		deriv[i] = ac[i] - ac[i - 1];
	}
	for (size_t i = 0; i < count; i++) {
		sq[i] = deriv[i] * deriv[i];
	}

	float win_sum = 0.0f;
	for (size_t i = 0; i < count; i++) {
		win_sum += sq[i];
		if (i >= MWI_WIDTH) {
			win_sum -= sq[i - MWI_WIDTH];
		}
		mwi[i] = win_sum / (float)MWI_WIDTH;
	}

	/* Adaptive threshold peak detection */
	float running_peak = 0.0f;
	for (size_t i = 0; i < count / 2; i++) {
		if (mwi[i] > running_peak) {
			running_peak = mwi[i];
		}
	}
	float threshold = running_peak * 0.5f;

	uint16_t peak_locs[MAX_PEAKS];
	uint8_t  n_peaks     = 0;
	size_t   last_peak   = 0;
	bool     above       = false;
	float    rise_val    = 0.0f;
	size_t   rise_idx    = 0;

	for (size_t i = 1; i < count && n_peaks < MAX_PEAKS; i++) {
		if (!above && mwi[i] > threshold) {
			above    = true;
			rise_val = mwi[i];
			rise_idx = i;
		} else if (above && mwi[i] < threshold) {
			above = false;
			if (n_peaks > 0 && (rise_idx - last_peak) < REFRACTORY) {
				continue;
			}
			peak_locs[n_peaks++] = (uint16_t)rise_idx;
			last_peak  = rise_idx;
			running_peak = running_peak * 0.875f + rise_val * 0.125f;
			threshold    = running_peak * 0.5f;
		}
	}

	if (n_peaks < 2) {
		LOG_DBG("Not enough peaks (%u)", n_peaks);
		return 0;
	}

	float total = 0.0f;
	for (uint8_t i = 1; i < n_peaks; i++) {
		total += (float)(peak_locs[i] - peak_locs[i - 1]);
	}
	float mean_interval_sec = (total / (float)(n_peaks - 1))
				  / (float)sample_hz;
	float bpm = 60.0f / mean_interval_sec;

	if (bpm < 30.0f || bpm > 220.0f) {
		LOG_DBG("BPM out of range: %.1f", (double)bpm);
		return 0;
	}

	LOG_INF("HR: %.1f bpm (peaks=%u)", (double)bpm, n_peaks);
	return (uint8_t)(bpm + 0.5f);
}
