#ifndef DRIVERS_MAX30102_H_
#define DRIVERS_MAX30102_H_

#include <zephyr/device.h>
#include <stdint.h>

#define MAX30102_I2C_ADDR    0x57

/* Registers */
#define MAX30102_REG_INT_STATUS1  0x00
#define MAX30102_REG_INT_STATUS2  0x01
#define MAX30102_REG_INT_ENABLE1  0x02
#define MAX30102_REG_INT_ENABLE2  0x03
#define MAX30102_REG_FIFO_WR_PTR  0x04
#define MAX30102_REG_OVF_COUNTER  0x05
#define MAX30102_REG_FIFO_RD_PTR  0x06
#define MAX30102_REG_FIFO_DATA    0x07
#define MAX30102_REG_FIFO_CONFIG  0x08
#define MAX30102_REG_MODE_CONFIG  0x09
#define MAX30102_REG_SPO2_CONFIG  0x0A
#define MAX30102_REG_LED1_PA      0x0C
#define MAX30102_REG_LED2_PA      0x0D
#define MAX30102_REG_PART_ID      0xFF

/* Mode */
#define MAX30102_MODE_SPO2        0x03
#define MAX30102_MODE_RESET       0x40

/* FIFO */
#define MAX30102_FIFO_SMP_AVE_4   0x40
#define MAX30102_FIFO_ROLLOVER_EN 0x10
#define MAX30102_FIFO_A_FULL_15   0x0F

/* SpO2 */
#define MAX30102_SPO2_ADC_RGE_4096 0x20
#define MAX30102_SPO2_SR_100       0x04
#define MAX30102_SPO2_LED_PW_411   0x03

/* 25 effective sps after 4x HW averaging */
#define MAX30102_SAMPLE_RATE_HZ   25U
#define MAX30102_SAMPLES_PER_CALC 150U

struct max30102_raw_sample {
	uint32_t red;
	uint32_t ir;
};

int     max30102_init(const struct device *dev);
int     max30102_drain_fifo(const struct device *dev,
			    struct max30102_raw_sample *out_buf,
			    uint8_t max_samples);
uint8_t max30102_compute_hr(const uint32_t *ir_buf, size_t count,
			    uint32_t sample_hz);

#endif /* DRIVERS_MAX30102_H_ */
