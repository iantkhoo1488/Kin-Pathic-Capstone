/*
 * MAX30102 driver - NCS v3.2.4
 *
 * HR algorithm: Pan-Tompkins inspired peak detection
 *   1. DC removal (mean subtraction)
 *   2. First derivative to find rising/falling slopes
 *   3. Squaring to amplify peaks and suppress noise
 *   4. Moving-window integration to smooth the signal
 *   5. Adaptive threshold: starts at 50% of first window max,
 *      then tracks as 50% of running peak average
 *   6. Refractory period blocks re-detection within 300 ms
 *   7. BPM from mean inter-peak interval across all detected peaks
 *
 * Signal quality:
 *   - Finger presence: IR mean > FINGER_THRESHOLD
 *   - Quality metric: AC amplitude / DC mean (perfusion index proxy)
 *     Values below QUALITY_THRESHOLD are flagged as poor contact.
 */

#include <zephyr/kernel.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/logging/log.h>
#include <string.h>
#include <math.h>

#include "max30102.h"

LOG_MODULE_REGISTER(max30102, LOG_LEVEL_INF);

/* Moving-window integration width (samples) */
#define MWI_WIDTH   8U

/* Refractory period: min samples between peaks (300 ms @ 25 Hz = 7 samples) */
#define REFRACTORY  7U

/* Maximum peaks we track in one window */
#define MAX_PEAKS   20U

/* ------------------------------------------------------------------ */
/* Register helpers                                                    */
/* ------------------------------------------------------------------ */

static int reg_write(const struct device *dev, uint8_t reg, uint8_t val)
{
	uint8_t buf[2] = { reg, val };
	return i2c_write(dev, buf, sizeof(buf), MAX30102_I2C_ADDR);
}

static int reg_read(const struct device *dev, uint8_t reg,
		    uint8_t *out, size_t len)
{
	return i2c_write_read(dev, MAX30102_I2C_ADDR, &reg, 1, out, len);
}

/* ------------------------------------------------------------------ */
/* Init                                                                */
/* ------------------------------------------------------------------ */

int max30102_init(const struct device *dev)
{
	int ret;
	uint8_t part_id;

	if (!device_is_ready(dev)) {
		LOG_ERR("I2C device not ready");
		return -ENODEV;
	}

	ret = reg_read(dev, MAX30102_REG_PART_ID, &part_id, 1);
	if (ret < 0) {
		LOG_ERR("PART_ID read failed: %d", ret);
		return ret;
	}
	if (part_id != 0x15) {
		LOG_ERR("Wrong PART_ID: 0x%02X (want 0x15)", part_id);
		return -ENODEV;
	}
	LOG_INF("MAX30102 found (PART_ID=0x%02X)", part_id);

	/* Soft reset */
	ret = reg_write(dev, MAX30102_REG_MODE_CONFIG, MAX30102_MODE_RESET);
	if (ret < 0) {
		return ret;
	}
	k_msleep(10);

	/*
	 * FIFO: 4-sample hardware averaging reduces noise and effective
	 * sample rate to 25 Hz, which is plenty for HR detection.
	 * Rollover on, almost-full at 15 remaining slots.
	 */
	ret = reg_write(dev, MAX30102_REG_FIFO_CONFIG,
			MAX30102_FIFO_SMP_AVE_4 |
			MAX30102_FIFO_ROLLOVER_EN |
			MAX30102_FIFO_A_FULL_15);
	if (ret < 0) {
		return ret;
	}

	/* SpO2: 4096 nA full scale, 100 sps (25 effective), 411 us pw */
	ret = reg_write(dev, MAX30102_REG_SPO2_CONFIG,
			MAX30102_SPO2_ADC_RGE_4096 |
			MAX30102_SPO2_SR_100 |
			MAX30102_SPO2_LED_PW_411);
	if (ret < 0) {
		return ret;
	}

	/* LED current ~7.2 mA */
	ret = reg_write(dev, MAX30102_REG_LED1_PA, 0x24);
	if (ret < 0) {
		return ret;
	}
	ret = reg_write(dev, MAX30102_REG_LED2_PA, 0x24);
	if (ret < 0) {
		return ret;
	}

	/* SpO2 mode (Red + IR) */
	ret = reg_write(dev, MAX30102_REG_MODE_CONFIG, MAX30102_MODE_SPO2);
	if (ret < 0) {
		return ret;
	}

	/* Clear FIFO */
	reg_write(dev, MAX30102_REG_FIFO_WR_PTR, 0x00);
	reg_write(dev, MAX30102_REG_OVF_COUNTER,  0x00);
	reg_write(dev, MAX30102_REG_FIFO_RD_PTR, 0x00);

	LOG_INF("MAX30102 ready (4x averaging, 25 sps effective)");
	return 0;
}

/* ------------------------------------------------------------------ */
/* FIFO read                                                           */
/* ------------------------------------------------------------------ */

int max30102_read_sample(const struct device *dev,
			 struct max30102_raw_sample *sample)
{
	uint8_t wr_ptr, rd_ptr;
	int ret;

	ret = reg_read(dev, MAX30102_REG_FIFO_WR_PTR, &wr_ptr, 1);
	if (ret < 0) {
		return ret;
	}
	ret = reg_read(dev, MAX30102_REG_FIFO_RD_PTR, &rd_ptr, 1);
	if (ret < 0) {
		return ret;
	}
	if (wr_ptr == rd_ptr) {
		return 0;
	}

	uint8_t raw[6];
	ret = reg_read(dev, MAX30102_REG_FIFO_DATA, raw, sizeof(raw));
	if (ret < 0) {
		return ret;
	}

	sample->red = ((uint32_t)(raw[0] & 0x03) << 16) |
		      ((uint32_t)raw[1] << 8) |
		       (uint32_t)raw[2];
	sample->ir  = ((uint32_t)(raw[3] & 0x03) << 16) |
		      ((uint32_t)raw[4] << 8) |
		       (uint32_t)raw[5];
	return 1;
}

/* ------------------------------------------------------------------ */
/* HR algorithm                                                        */
/* ------------------------------------------------------------------ */

void max30102_compute_hr(const uint32_t *ir_buf, size_t count,
			 uint32_t sample_hz,
			 struct max30102_hr_result *result)
{
	result->bpm            = 0;
	result->finger_present = false;
	result->signal_quality = 0.0f;

	if (count < 10 || sample_hz == 0) {
		return;
	}

	/* --- 1. DC mean and finger check --- */
	int64_t sum = 0;
	uint32_t ir_min = ir_buf[0], ir_max = ir_buf[0];

	for (size_t i = 0; i < count; i++) {
		sum += ir_buf[i];
		if (ir_buf[i] < ir_min) {
			ir_min = ir_buf[i];
		}
		if (ir_buf[i] > ir_max) {
			ir_max = ir_buf[i];
		}
	}
	float dc_mean = (float)sum / (float)count;

	if (dc_mean < (float)MAX30102_FINGER_THRESHOLD) {
		LOG_DBG("No finger detected (IR mean=%.0f)", (double)dc_mean);
		return;
	}
	result->finger_present = true;

	/* --- 2. Signal quality: AC/DC ratio (perfusion index proxy) --- */
	float ac_amplitude = (float)(ir_max - ir_min) / 2.0f;
	result->signal_quality = ac_amplitude / dc_mean;

	if (result->signal_quality < MAX30102_QUALITY_THRESHOLD) {
		LOG_WRN("Poor signal quality: %.4f (check finger pressure)",
			(double)result->signal_quality);
		return;
	}

	/* --- 3. DC removal: subtract mean --- */
	/* Use a static buffer to avoid stack pressure on embedded target */
	static float ac[MAX30102_SAMPLES_PER_CALC];

	if (count > MAX30102_SAMPLES_PER_CALC) {
		count = MAX30102_SAMPLES_PER_CALC;
	}
	for (size_t i = 0; i < count; i++) {
		ac[i] = (float)ir_buf[i] - dc_mean;
	}

	/* --- 4. Derivative (slope) --- */
	static float deriv[MAX30102_SAMPLES_PER_CALC];
	deriv[0] = 0.0f;
	for (size_t i = 1; i < count; i++) {
		deriv[i] = ac[i] - ac[i - 1];
	}

	/* --- 5. Square to amplify and make positive --- */
	static float sq[MAX30102_SAMPLES_PER_CALC];
	for (size_t i = 0; i < count; i++) {
		sq[i] = deriv[i] * deriv[i];
	}

	/* --- 6. Moving-window integration --- */
	static float mwi[MAX30102_SAMPLES_PER_CALC];
	float win_sum = 0.0f;

	for (size_t i = 0; i < count; i++) {
		win_sum += sq[i];
		if (i >= MWI_WIDTH) {
			win_sum -= sq[i - MWI_WIDTH];
		}
		mwi[i] = win_sum / (float)MWI_WIDTH;
	}

	/* --- 7. Adaptive threshold peak detection --- */

	/* Initial threshold: 50% of max in first half of window */
	float running_peak = 0.0f;
	size_t half = count / 2;
	for (size_t i = 0; i < half; i++) {
		if (mwi[i] > running_peak) {
			running_peak = mwi[i];
		}
	}
	float threshold = running_peak * 0.5f;

	uint16_t peak_locs[MAX_PEAKS];
	uint8_t  n_peaks = 0;
	size_t   last_peak = 0;
	bool     above = false;
	float    rise_start_val = 0.0f;
	size_t   rise_start_idx = 0;

	for (size_t i = 1; i < count && n_peaks < MAX_PEAKS; i++) {
		if (!above && mwi[i] > threshold) {
			above = true;
			rise_start_val = mwi[i];
			rise_start_idx = i;
		} else if (above && mwi[i] < threshold) {
			above = false;

			/* Enforce refractory period */
			if (n_peaks > 0 &&
			    (rise_start_idx - last_peak) < REFRACTORY) {
				continue;
			}

			/* Record peak at midpoint of the crossing region */
			peak_locs[n_peaks++] = (uint16_t)rise_start_idx;
			last_peak = rise_start_idx;

			/* Update adaptive threshold */
			running_peak = running_peak * 0.875f +
				       rise_start_val * 0.125f;
			threshold = running_peak * 0.5f;
		}
	}

	LOG_DBG("Peaks detected: %u (threshold=%.2f)", n_peaks,
		(double)threshold);

	if (n_peaks < 2) {
		LOG_WRN("Not enough peaks (%u) for HR calculation", n_peaks);
		return;
	}

	/* --- 8. BPM from mean inter-peak interval --- */
	float total_interval = 0.0f;
	for (uint8_t i = 1; i < n_peaks; i++) {
		total_interval += (float)(peak_locs[i] - peak_locs[i - 1]);
	}
	float mean_interval_samples = total_interval / (float)(n_peaks - 1);
	float mean_interval_sec     = mean_interval_samples / (float)sample_hz;
	float bpm                   = 60.0f / mean_interval_sec;

	if (bpm < 30.0f || bpm > 250.0f) {
		LOG_WRN("BPM out of range: %.1f", (double)bpm);
		return;
	}

	result->bpm = (uint8_t)(bpm + 0.5f);
	LOG_INF("HR: %u bpm | quality=%.3f | peaks=%u",
		result->bpm,
		(double)result->signal_quality,
		n_peaks);
}
