#ifndef DRIVERS_MAX30102_H_
#define DRIVERS_MAX30102_H_

#include <zephyr/device.h>
#include <stdint.h>
#include <stdbool.h>

/* I2C address */
#define MAX30102_I2C_ADDR    0x57

/* Registers */
#define MAX30102_REG_INT_STATUS1  0x00
#define MAX30102_REG_INT_STATUS2  0x01
#define MAX30102_REG_INT_ENABLE1  0x02
#define MAX30102_REG_INT_ENABLE2  0x03
#define MAX30102_REG_FIFO_WR_PTR  0x04
#define MAX30102_REG_OVF_COUNTER  0x05
#define MAX30102_REG_FIFO_RD_PTR  0x06
#define MAX30102_REG_FIFO_DATA    0x07
#define MAX30102_REG_FIFO_CONFIG  0x08
#define MAX30102_REG_MODE_CONFIG  0x09
#define MAX30102_REG_SPO2_CONFIG  0x0A
#define MAX30102_REG_LED1_PA      0x0C
#define MAX30102_REG_LED2_PA      0x0D
#define MAX30102_REG_PART_ID      0xFF

/* Mode config */
#define MAX30102_MODE_SPO2        0x03
#define MAX30102_MODE_RESET       0x40

/* FIFO config */
#define MAX30102_FIFO_SMP_AVE_4   0x40  /* 4-sample averaging for noise reduction */
#define MAX30102_FIFO_ROLLOVER_EN 0x10
#define MAX30102_FIFO_A_FULL_15   0x0F

/* SpO2 config */
#define MAX30102_SPO2_ADC_RGE_4096 0x20
#define MAX30102_SPO2_SR_100       0x04
#define MAX30102_SPO2_LED_PW_411   0x03

/*
 * Sampling config
 * 100 sps / 4-sample averaging = 25 effective samples/sec
 * Window of 150 effective samples = ~6 seconds (good for 40-180 bpm range)
 */
#define MAX30102_SAMPLE_RATE_HZ    25U   /* effective rate after averaging */
#define MAX30102_SAMPLES_PER_CALC  150U  /* ~6 second window */

/*
 * Signal quality thresholds
 * IR value below FINGER_THRESHOLD = no finger detected
 * AC/DC ratio below QUALITY_THRESHOLD = poor contact / motion artefact
 */
#define MAX30102_FINGER_THRESHOLD   50000UL   /* raw ADC counts */
#define MAX30102_QUALITY_THRESHOLD  0.005f    /* AC/DC ratio floor */

/* Result of a single HR calculation */
struct max30102_hr_result {
	uint8_t  bpm;           /* 0 = invalid */
	bool     finger_present;
	float    signal_quality; /* 0.0 - 1.0 */
};

struct max30102_raw_sample {
	uint32_t red;
	uint32_t ir;
};

int  max30102_init(const struct device *dev);
int  max30102_read_sample(const struct device *dev,
			  struct max30102_raw_sample *sample);

/**
 * @brief Compute heart rate using Pan-Tompkins-inspired peak detection.
 *
 * Steps:
 *  1. Signal quality / finger presence check.
 *  2. DC removal via mean subtraction.
 *  3. Derivative + squaring to emphasise slopes.
 *  4. Moving-window integration.
 *  5. Adaptive threshold peak detection.
 *  6. BPM from mean inter-peak interval.
 *
 * @param ir_buf    Buffer of IR samples (length MAX30102_SAMPLES_PER_CALC).
 * @param count     Number of samples.
 * @param sample_hz Effective sample rate in Hz.
 * @param result    Output struct with bpm, quality, finger flag.
 */
void max30102_compute_hr(const uint32_t *ir_buf, size_t count,
			 uint32_t sample_hz,
			 struct max30102_hr_result *result);

#endif /* DRIVERS_MAX30102_H_ */
