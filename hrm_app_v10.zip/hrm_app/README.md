# Heart Rate Monitor — Zephyr Application
## nRF52-DK (nRF52832) + MAX30102

---

## Hardware

| MAX30102 Pin | nRF52-DK Pin | GPIO  |
|--------------|-------------|-------|
| VIN / VCC    | VDD (3.3 V) | —     |
| GND          | GND         | —     |
| SDA          | P11 header  | P0.26 |
| SCL          | P12 header  | P0.27 |
| INT          | (optional)  | —     |

> **Note:** The nRF52-DK exposes P0.26 and P0.27 on the Arduino-compatible
> header. Double-check your silkscreen — pin numbers may differ between
> board revisions. Both lines need 4.7 kΩ pull-ups to 3.3 V if your
> MAX30102 breakout board does not already include them.

---

## Project structure

```
hrm_app/
├── boards/
│   └── nrf52dk_nrf52832.overlay   # Devicetree: I2C + MAX30102 node
├── drivers/
│   └── max30102/
│       ├── max30102.h             # Driver API
│       └── max30102.c             # I2C communication + HR algorithm
├── src/
│   ├── main.c                     # Application entry point
│   ├── ble_hrs.h                  # BLE HRS API
│   └── ble_hrs.c                  # BLE Heart Rate Service (GATT)
├── CMakeLists.txt
└── prj.conf                       # Kconfig options
```

---

## Prerequisites

- **Zephyr SDK** ≥ 0.16 and **West** installed
  (`pip install west`, then `west init` / `west update`)
- nRF52 DK connected via USB (J-Link on-board)
- Optional: **nRF Connect** mobile app (iOS / Android) to visualise HR

---

## Build

```bash
# From the Zephyr workspace root:
west build -b nrf52dk_nrf52832 path/to/hrm_app
```

### Flash

```bash
west flash
```

### Monitor logs (RTT)

```bash
# Using J-Link RTT Viewer, or:
west espressif monitor   # not applicable for nRF52
JLinkRTTLogger -device NRF52832_XXAA -if SWD -speed 4000 -RTTChannel 0 /dev/stdout
```

Or use the **nRF Terminal** in VS Code with the nRF Connect extension.

---

## Connecting from a central device

### nRF Connect mobile app (recommended for testing)

1. Open **nRF Connect** → Scanner tab.
2. Look for **HRM_nRF52** and tap **Connect**.
3. Navigate to the **Heart Rate Service (0x180D)**.
4. Tap the **notify** button (↓) on **Heart Rate Measurement (0x2A37)**.
5. Values update every ~1 second (1 window = 100 samples at 100 sps).

### Any BLE central (Linux / Python)

```python
# Example using bleak (pip install bleak)
import asyncio
from bleak import BleakClient

HRM_UUID = "00002a37-0000-1000-8000-00805f9b34fb"

async def main():
    async with BleakClient("XX:XX:XX:XX:XX:XX") as c:
        def cb(_, data):
            bpm = data[1]   # flags byte [0], HR byte [1]
            print(f"Heart rate: {bpm} bpm")
        await c.start_notify(HRM_UUID, cb)
        await asyncio.sleep(60)

asyncio.run(main())
```

Replace `XX:XX:XX:XX:XX:XX` with your device's BLE MAC address (shown in
the nRF Connect scanner).

---

## Tuning

| Parameter | Location | Effect |
|-----------|----------|--------|
| LED current | `max30102.c` `MAX30102_REG_LED1/2_PA` | Increase if weak signal; 0x24 ≈ 7.2 mA |
| Sample rate | `prj.conf` → `SAMPLE_RATE_HZ` + `MAX30102_REG_SPO2_CONFIG` | Higher = smoother HR but more power |
| Window size | `max30102.h` `MAX30102_SAMPLES_PER_CALC` | Larger = more accurate but slower update |
| HR algorithm | `max30102.c` `max30102_compute_hr()` | Replace with a more sophisticated algorithm (e.g. Pan-Tompkins) for production use |

---

## Known limitations / future work

- The heart rate algorithm is intentionally simple (zero-crossing on the
  DC-removed IR signal). It works well for resting HR but may struggle
  with motion artefacts or fast heart rates. Consider integrating a
  dedicated library such as **HeartPy** on the host side, or implementing
  Pan-Tompkins on-device.
- SpO2 (blood oxygen) calculation is not included but the raw Red + IR
  data is available from `max30102_read_sample()`.
- No bonding / pairing is enforced. Add `CONFIG_BT_BONDABLE=y` and pair
  the device if security is required.
