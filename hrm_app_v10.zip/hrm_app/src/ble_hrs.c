/*
 * BLE Heart Rate Service - NCS v3.2.4
 *
 * Error 133 fix: request MTU exchange immediately on connect.
 * Many phones (especially Android) expect the peripheral to
 * initiate MTU exchange. If it doesn't happen fast enough the
 * phone drops the connection with GATT error 133.
 */

#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>
#include <zephyr/bluetooth/gap.h>
#include <zephyr/logging/log.h>
#include <zephyr/kernel.h>

#include "ble_hrs.h"

LOG_MODULE_REGISTER(ble_hrs, LOG_LEVEL_INF);

/* ------------------------------------------------------------------ */
/* State                                                               */
/* ------------------------------------------------------------------ */

static struct bt_conn *current_conn;
static bool            hrs_notify_enabled;

static int start_advertising(void);

/* ------------------------------------------------------------------ */
/* MTU exchange callback                                               */
/* ------------------------------------------------------------------ */

static void mtu_exchange_cb(struct bt_conn *conn, uint8_t err,
			    struct bt_gatt_exchange_params *params)
{
	if (err) {
		LOG_WRN("MTU exchange failed (err %u)", err);
	} else {
		LOG_INF("MTU exchanged: %u bytes",
			bt_gatt_get_mtu(conn));
	}
}

static struct bt_gatt_exchange_params mtu_params = {
	.func = mtu_exchange_cb,
};

/* ------------------------------------------------------------------ */
/* Connection callbacks                                                */
/* ------------------------------------------------------------------ */

static void on_connected(struct bt_conn *conn, uint8_t err)
{
	if (err) {
		LOG_ERR("Connection failed (err 0x%02x)", err);
		return;
	}

	LOG_INF("Connected");
	current_conn = bt_conn_ref(conn);

	/*
	 * Initiate MTU exchange immediately on connect.
	 * This is the primary fix for error 133 — without it,
	 * Android drops the connection during GATT discovery.
	 */
	int ret = bt_gatt_exchange_mtu(conn, &mtu_params);
	if (ret) {
		LOG_WRN("MTU exchange request failed: %d", ret);
	}
}

static void on_disconnected(struct bt_conn *conn, uint8_t reason)
{
	LOG_INF("Disconnected (reason 0x%02x)", reason);
	if (current_conn) {
		bt_conn_unref(current_conn);
		current_conn = NULL;
	}
	hrs_notify_enabled = false;

	int ret = start_advertising();
	if (ret) {
		LOG_ERR("Re-advertising failed: %d", ret);
	}
}

BT_CONN_CB_DEFINE(conn_callbacks) = {
	.connected    = on_connected,
	.disconnected = on_disconnected,
};

/* ------------------------------------------------------------------ */
/* GATT CCC callback                                                   */
/* ------------------------------------------------------------------ */

static void hrm_ccc_changed(const struct bt_gatt_attr *attr, uint16_t value)
{
	hrs_notify_enabled = (value == BT_GATT_CCC_NOTIFY);
	LOG_INF("HRS notify %s", hrs_notify_enabled ? "enabled" : "disabled");
}

/* ------------------------------------------------------------------ */
/* GATT service                                                        */
/* ------------------------------------------------------------------ */

static ssize_t read_body_sensor_location(struct bt_conn *conn,
					 const struct bt_gatt_attr *attr,
					 void *buf, uint16_t len,
					 uint16_t offset)
{
	uint8_t bsl = 0x02; /* Wrist */
	return bt_gatt_attr_read(conn, attr, buf, len, offset,
				 &bsl, sizeof(bsl));
}

static ssize_t write_hr_control_point(struct bt_conn *conn,
				      const struct bt_gatt_attr *attr,
				      const void *buf, uint16_t len,
				      uint16_t offset, uint8_t flags)
{
	if (len != 1) {
		return BT_GATT_ERR(BT_ATT_ERR_INVALID_ATTRIBUTE_LEN);
	}
	uint8_t cmd = ((const uint8_t *)buf)[0];
	if (cmd == 0x01) {
		LOG_INF("HR control point: reset energy expended");
	} else {
		return BT_GATT_ERR(BT_ATT_ERR_NOT_SUPPORTED);
	}
	return len;
}

BT_GATT_SERVICE_DEFINE(hrs_svc,
	BT_GATT_PRIMARY_SERVICE(BT_UUID_HRS),

	BT_GATT_CHARACTERISTIC(BT_UUID_HRS_MEASUREMENT,
			       BT_GATT_CHRC_NOTIFY,
			       BT_GATT_PERM_NONE,
			       NULL, NULL, NULL),
	BT_GATT_CCC(hrm_ccc_changed,
		    BT_GATT_PERM_READ | BT_GATT_PERM_WRITE),

	BT_GATT_CHARACTERISTIC(BT_UUID_HRS_BODY_SENSOR,
			       BT_GATT_CHRC_READ,
			       BT_GATT_PERM_READ,
			       read_body_sensor_location, NULL, NULL),

	BT_GATT_CHARACTERISTIC(BT_UUID_HRS_CONTROL_POINT,
			       BT_GATT_CHRC_WRITE,
			       BT_GATT_PERM_WRITE,
			       NULL, write_hr_control_point, NULL),
);

/* ------------------------------------------------------------------ */
/* Advertising                                                         */
/* ------------------------------------------------------------------ */

static const struct bt_data ad[] = {
	BT_DATA_BYTES(BT_DATA_FLAGS,
		      BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR),
	BT_DATA_BYTES(BT_DATA_UUID16_ALL,
		      BT_UUID_16_ENCODE(BT_UUID_HRS_VAL)),
	BT_DATA(BT_DATA_NAME_COMPLETE,
		CONFIG_BT_DEVICE_NAME,
		sizeof(CONFIG_BT_DEVICE_NAME) - 1),
};

static const struct bt_le_adv_param adv_param = {
	.id                 = BT_ID_DEFAULT,
	.sid                = 0,
	.secondary_max_skip = 0,
	.options            = BT_LE_ADV_OPT_CONN,
	.interval_min       = BT_GAP_ADV_FAST_INT_MIN_2,
	.interval_max       = BT_GAP_ADV_FAST_INT_MAX_2,
	.peer               = NULL,
};

static int start_advertising(void)
{
	int err = bt_le_adv_start(&adv_param, ad, ARRAY_SIZE(ad), NULL, 0);
	if (!err) {
		LOG_INF("Advertising started");
	}
	return err;
}

/* ------------------------------------------------------------------ */
/* Public API                                                          */
/* ------------------------------------------------------------------ */

int bt_hrs_init(void)
{
	int err = bt_enable(NULL);
	if (err) {
		LOG_ERR("bt_enable failed: %d", err);
		return err;
	}

	err = start_advertising();
	if (err) {
		LOG_ERR("Advertising start failed: %d", err);
		return err;
	}

	LOG_INF("BLE HRS ready, advertising as \"%s\"",
		CONFIG_BT_DEVICE_NAME);
	return 0;
}

int bt_hrs_notify(uint8_t bpm)
{
	if (!hrs_notify_enabled || !current_conn) {
		return -ENOTCONN;
	}

	uint8_t hrm[2] = { 0x00, bpm };

	return bt_gatt_notify(current_conn, &hrs_svc.attrs[1],
			      hrm, sizeof(hrm));
}
