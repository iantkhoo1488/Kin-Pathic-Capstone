/*
 * Heart Rate Monitor - main application
 * NCS v3.2.4 / nRF52-DK + MAX30102
 *
 * BLE smoothing strategy:
 *   - Maintains a circular buffer of the last BLE_AVG_WINDOW valid BPM readings
 *   - Discards readings that deviate more than BLE_SPIKE_THRESHOLD bpm from
 *     the current running average (spike rejection)
 *   - Notifies BLE every BLE_NOTIFY_INTERVAL_MS ms using the averaged value
 *   - Only notifies if the averaged value has changed by at least 1 bpm
 */

#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/logging/log.h>

#include "../drivers/max30102/max30102.h"
#include "ble_hrs.h"

LOG_MODULE_REGISTER(main, LOG_LEVEL_INF);

#define I2C_NODE DT_NODELABEL(i2c0)

/* Sampling: 10ms interval matches the 25 Hz effective rate after averaging */
#define SAMPLE_INTERVAL_MS   40U

/*
 * BLE notification smoothing
 *   BLE_AVG_WINDOW      - number of valid readings to average (last N)
 *   BLE_NOTIFY_INTERVAL - how often to push a BLE notification (ms)
 *   BLE_SPIKE_THRESHOLD - reject readings this far from running average
 *   BLE_MIN_QUALITY     - minimum signal quality to accept a reading
 */
#define BLE_AVG_WINDOW        5U
#define BLE_NOTIFY_INTERVAL   3000U
#define BLE_SPIKE_THRESHOLD   20U
#define BLE_MIN_QUALITY       0.01f

/* ------------------------------------------------------------------ */
/* BLE smoothing state                                                 */
/* ------------------------------------------------------------------ */

static uint8_t  bpm_history[BLE_AVG_WINDOW];
static uint8_t  history_count = 0;
static uint8_t  history_idx   = 0;
static uint8_t  last_notified_bpm = 0;
static int64_t  last_notify_ms    = 0;

static void history_add(uint8_t bpm)
{
	bpm_history[history_idx] = bpm;
	history_idx = (history_idx + 1) % BLE_AVG_WINDOW;
	if (history_count < BLE_AVG_WINDOW) {
		history_count++;
	}
}

static uint8_t history_average(void)
{
	if (history_count == 0) {
		return 0;
	}
	uint32_t sum = 0;
	for (uint8_t i = 0; i < history_count; i++) {
		sum += bpm_history[i];
	}
	return (uint8_t)((sum + history_count / 2) / history_count);
}

/*
 * Accept a new BPM reading:
 *   - Reject if no finger or poor quality
 *   - Reject if it spikes more than BLE_SPIKE_THRESHOLD from current avg
 *     (only once we have enough history to judge)
 *   - Otherwise add to circular buffer
 * Returns the smoothed average, or 0 if not enough data yet.
 */
static uint8_t smooth_bpm(const struct max30102_hr_result *r)
{
	if (!r->finger_present || r->bpm == 0) {
		/* Finger removed — clear history so stale readings don't linger */
		history_count = 0;
		history_idx   = 0;
		return 0;
	}

	if (r->signal_quality < BLE_MIN_QUALITY) {
		LOG_WRN("Reading rejected: quality too low (%.3f)",
			(double)r->signal_quality);
		return history_average();
	}

	if (history_count >= 2) {
		uint8_t avg = history_average();
		int diff = (int)r->bpm - (int)avg;
		if (diff < 0) {
			diff = -diff;
		}
		if (diff > BLE_SPIKE_THRESHOLD) {
			LOG_WRN("Spike rejected: %u bpm (avg=%u, diff=%d)",
				r->bpm, avg, diff);
			return avg;
		}
	}

	history_add(r->bpm);
	return history_average();
}

/* ------------------------------------------------------------------ */
/* Main                                                                */
/* ------------------------------------------------------------------ */

int main(void)
{
	LOG_INF("Heart Rate Monitor starting");

	/* --- BLE --- */
	int ret = bt_hrs_init();
	if (ret) {
		LOG_ERR("BLE init failed: %d", ret);
		return ret;
	}

	/* --- I2C --- */
	const struct device *i2c_dev = DEVICE_DT_GET(I2C_NODE);

	if (!device_is_ready(i2c_dev)) {
		LOG_ERR("I2C device not ready");
		return -ENODEV;
	}

	/* --- Sensor --- */
	ret = max30102_init(i2c_dev);
	if (ret) {
		LOG_ERR("MAX30102 init failed: %d", ret);
		return ret;
	}

	/* --- Sampling buffer --- */
	static uint32_t ir_buf[MAX30102_SAMPLES_PER_CALC];
	size_t n = 0;

	LOG_INF("Collecting %u samples per window (~%u s)",
		MAX30102_SAMPLES_PER_CALC,
		MAX30102_SAMPLES_PER_CALC / MAX30102_SAMPLE_RATE_HZ);

	while (1) {
		struct max30102_raw_sample s;
		int got = max30102_read_sample(i2c_dev, &s);

		if (got == 1) {
			ir_buf[n++] = s.ir;

			if (n >= MAX30102_SAMPLES_PER_CALC) {
				/* Run HR algorithm */
				struct max30102_hr_result result;

				max30102_compute_hr(ir_buf,
						    MAX30102_SAMPLES_PER_CALC,
						    MAX30102_SAMPLE_RATE_HZ,
						    &result);

				/* Smooth the result */
				uint8_t smoothed = smooth_bpm(&result);

				if (!result.finger_present) {
					LOG_INF("No finger detected");
				} else if (smoothed == 0) {
					LOG_INF("Collecting baseline...");
				} else {
					LOG_INF("HR (smoothed): %u bpm | "
						"raw: %u | quality: %.3f",
						smoothed, result.bpm,
						(double)result.signal_quality);

					/* Rate-limited BLE notification */
					int64_t now = k_uptime_get();
					bool time_ok = (now - last_notify_ms)
						       >= BLE_NOTIFY_INTERVAL;
					bool changed = (smoothed !=
							last_notified_bpm);

					if (time_ok && changed) {
						ret = bt_hrs_notify(smoothed);
						if (ret == 0) {
							last_notified_bpm = smoothed;
							last_notify_ms = now;
						} else if (ret != -ENOTCONN) {
							LOG_WRN("Notify failed: %d",
								ret);
						}
					}
				}

				/* Slide window: keep last 50% of samples
				 * for continuity rather than hard-resetting */
				size_t keep = MAX30102_SAMPLES_PER_CALC / 2;
				memmove(ir_buf,
					ir_buf + (MAX30102_SAMPLES_PER_CALC - keep),
					keep * sizeof(uint32_t));
				n = keep;
			}
		} else if (got < 0) {
			LOG_ERR("Sensor read error: %d", got);
		}

		k_msleep(SAMPLE_INTERVAL_MS);
	}

	return 0;
}
