/*
 * Heart Rate Monitor - main application
 * NCS v3.2.4 / nRF52-DK + MAX30102
 *
 * Continuously collects samples in a circular buffer and runs
 * the HR algorithm every time a full window of NEW samples has
 * been collected. BLE notifications are sent on every valid result.
 */

#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/logging/log.h>
#include <string.h>

#include "../drivers/max30102/max30102.h"
#include "ble_hrs.h"

LOG_MODULE_REGISTER(main, LOG_LEVEL_INF);

#define I2C_NODE DT_NODELABEL(i2c0)

/* Poll sensor every 40ms (matches 25 Hz effective rate after HW averaging) */
#define SAMPLE_INTERVAL_MS   40U

/*
 * BLE smoothing
 *   BLE_AVG_WINDOW      - rolling average over last N valid readings
 *   BLE_SPIKE_THRESHOLD - reject readings this far from running average
 *   BLE_MIN_QUALITY     - minimum signal quality to accept a reading
 */
#define BLE_AVG_WINDOW        5U
#define BLE_SPIKE_THRESHOLD   20U
#define BLE_MIN_QUALITY       0.01f

/* ------------------------------------------------------------------ */
/* BLE smoothing state                                                 */
/* ------------------------------------------------------------------ */

static uint8_t bpm_history[BLE_AVG_WINDOW];
static uint8_t history_count;
static uint8_t history_idx;

static void history_reset(void)
{
	history_count = 0;
	history_idx   = 0;
}

static void history_add(uint8_t bpm)
{
	bpm_history[history_idx] = bpm;
	history_idx = (history_idx + 1) % BLE_AVG_WINDOW;
	if (history_count < BLE_AVG_WINDOW) {
		history_count++;
	}
}

static uint8_t history_average(void)
{
	if (history_count == 0) {
		return 0;
	}
	uint32_t sum = 0;
	for (uint8_t i = 0; i < history_count; i++) {
		sum += bpm_history[i];
	}
	return (uint8_t)((sum + history_count / 2) / history_count);
}

static uint8_t smooth_bpm(const struct max30102_hr_result *r)
{
	if (!r->finger_present || r->bpm == 0) {
		history_reset();
		return 0;
	}

	if (r->signal_quality < BLE_MIN_QUALITY) {
		LOG_WRN("Low quality (%.3f) - skipping",
			(double)r->signal_quality);
		return history_average();
	}

	/* Spike rejection once we have enough history */
	if (history_count >= 2) {
		uint8_t avg = history_average();
		int diff = (int)r->bpm - (int)avg;
		if (diff < 0) {
			diff = -diff;
		}
		if (diff > BLE_SPIKE_THRESHOLD) {
			LOG_WRN("Spike rejected: %u bpm (avg=%u)",
				r->bpm, avg);
			return avg;
		}
	}

	history_add(r->bpm);
	return history_average();
}

/* ------------------------------------------------------------------ */
/* Main                                                                */
/* ------------------------------------------------------------------ */

int main(void)
{
	LOG_INF("Heart Rate Monitor starting");

	int ret = bt_hrs_init();
	if (ret) {
		LOG_ERR("BLE init failed: %d", ret);
		return ret;
	}

	const struct device *i2c_dev = DEVICE_DT_GET(I2C_NODE);
	if (!device_is_ready(i2c_dev)) {
		LOG_ERR("I2C device not ready");
		return -ENODEV;
	}

	ret = max30102_init(i2c_dev);
	if (ret) {
		LOG_ERR("MAX30102 init failed: %d", ret);
		return ret;
	}

	static uint32_t ir_buf[MAX30102_SAMPLES_PER_CALC];
	size_t n = 0;

	LOG_INF("Running - window=%u samples (~%us)",
		MAX30102_SAMPLES_PER_CALC,
		MAX30102_SAMPLES_PER_CALC / MAX30102_SAMPLE_RATE_HZ);

	while (1) {
		struct max30102_raw_sample s;
		int got = max30102_read_sample(i2c_dev, &s);

		if (got == 1) {
			ir_buf[n++] = s.ir;

			/* Once a full window of samples is collected,
			 * run the algorithm then reset to collect the
			 * next fresh window from scratch. */
			if (n >= MAX30102_SAMPLES_PER_CALC) {
				struct max30102_hr_result result;

				max30102_compute_hr(ir_buf,
						    MAX30102_SAMPLES_PER_CALC,
						    MAX30102_SAMPLE_RATE_HZ,
						    &result);

				uint8_t smoothed = smooth_bpm(&result);

				if (!result.finger_present) {
					LOG_INF("No finger detected");
				} else if (smoothed == 0) {
					LOG_INF("Collecting baseline...");
				} else {
					LOG_INF("HR: %u bpm (raw=%u q=%.3f)",
						smoothed, result.bpm,
						(double)result.signal_quality);

					/* Notify on every valid reading */
					ret = bt_hrs_notify(smoothed);
					if (ret && ret != -ENOTCONN) {
						LOG_WRN("Notify failed: %d",
							ret);
					}
				}

				/* Reset buffer - collect a completely
				 * fresh window next time */
				n = 0;
			}
		} else if (got < 0) {
			LOG_ERR("Sensor read error: %d", got);
		}

		k_msleep(SAMPLE_INTERVAL_MS);
	}

	return 0;
}
